import java.io.*;
import java.net.*;

class clienteUDP {  

public void init(String args[]){  

// Leemos el primer par�metro, donde debe ir la direcci�n  
// IP del servidor
	InetAddress direcc = null;  
	try{  
		direcc = InetAddress.getByName(args[0]);  
	} catch(UnknownHostException uhe){  
		System.err.println("Host no encontrado : " + uhe);  
		System.exit(-1);  
	}//fin try

	// Puerto que hemos usado para el servidor  
	int puerto = 1234;  
 
 	// Creamos el Socket  
	DatagramSocket ds = null;  
	try{  
	   ds = new DatagramSocket();  
	} catch(SocketException se){  
		System.err.println("Error al abrir el socket : " + se);  
		System.exit(-1);  
	}//fin try 
	int cont = 0;
	// Para cada uno de los argumentos...  
	for (int n=1;n<args.length;n++){ 
	   // N�mero m�ximo de caracteres de una palabra ser� < 254
	   String palabra = args[n];
	   System.out.println("Cadena enviada por cliente: "+palabra);
	   try{  
	   	// Creamos un buffer para escribir  
		ByteArrayOutputStream baos = new ByteArrayOutputStream();  
	   	DataOutputStream dos = new DataOutputStream(baos);  
	    	// Lo escribimos  
	   	dos.writeBytes(args[n]+'$');
	   	// y cerramos el buffer  
	   	dos.close();  
	   	// Creamos paquete  
	   	DatagramPacket dp = new DatagramPacket(baos.toByteArray(),dos.size(),direcc,puerto);
	  	// y lo mandamos
	   	ds.send(dp);  
	   	// Preparamos buffer para recibir palabras  
	   	byte bufferEntrada[] = new byte[dos.size()+4];
	   	// Creamos el contenedor del paquete  
	   	dp = new DatagramPacket(bufferEntrada,dos.size()+4);  
	   	// y lo recibimos  
	   	ds.receive(dp);
	   	
	   	byte p[] = dp.getData();
	   	String resultado = new String(p);
	   	int pos = 0;
	   	pos = resultado.indexOf("$");
	   	// Indicamos en pantalla  
	   	System.out.println("Solicitud = " + args[n]);
	   	System.out.println("Resultado = " +resultado.replace('$',' '));  
	   	System.out.println("N�mero de caracteres cambiados : "+ resultado.charAt(pos+1)+" de la palabra n�mero "+n);
	   	System.out.println();
     	    } catch (Exception e){  
	     	System.err.println("Se ha producido un error : " + e);  
     	    }//fin try  
  	}//fin for
    }// fin init  
}//fin cliente
