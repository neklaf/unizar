
public class multiservidor{

	public static void main(String args[]){
		servidorTCP sTCP = new servidorTCP();
		servidorUDP sUDP = new servidorUDP();
		//Iniciar los dos servidores!!!
		sUDP.start();
		sTCP.start();
		
	}
}
