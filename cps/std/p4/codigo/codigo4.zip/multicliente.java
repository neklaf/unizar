import java.lang.*;

public class multicliente{

	static int generaCliente(){
		int num=0;
		num=(int)(Math.random()*100);
		return (num%2);
	}
	
	public static void main(String args[]){		
	if ( args.length != 2)
	{
		System.out.println("Formato: java multiservidor nb_maquina \"cadena_txt\"");
	}else{
		int num=generaCliente();
		System.out.println("El numero generado es: "+num);
		if ( num == 0 ){
			System.out.println("Generado cliente TCP");
			clienteTCP cTCP = new clienteTCP();
			cTCP.init(args);
		}else{
			System.out.println("Generado cliente UDP");
			clienteUDP cUDP = new clienteUDP();
			cUDP.init(args);
		}
	}
    }
}
