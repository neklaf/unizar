#ifndef __SERVIDOR_H_
#define __SERVIDOR_H_

long cuenta_primos (long min, long max);

int es_primo (long n);

long encuentra_primos (long min, long max, long *vector);

#endif
