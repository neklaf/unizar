/*
 * CLIENTE.C
 * Cliente de n�meros primos v0.1
 * (c) Sergio Paracuellos Guti�rrez
 */ 

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>


#define MAX_SIZE_BUFFER 256
#define MAX_FD 10
#define MAX_PORT 10
#define TRUE 0
#define FALSE 1

char *local="127.0.0.1";


int main (int argc, char *argv[]) {
    
  int fd[MAX_FD], numbytes; /* ficheros descriptores */
  struct hostent *he;  /* estructura que recibir� informaci�n sobre el nodo remoto */
  struct sockaddr_in server;  /* informaci�n sobre la direcci�n del servidor */
  long i,j,longitud=0;

  FILE *log_file; /* fichero de log */
  
  int puerto;
  int puertos[MAX_PORT];
  
  int encontrado; 

  long min=1L;
  long max=100L;
  long num_primos=0;
  long intervalo;
  long numero;


  long buffer[MAX_SIZE_BUFFER];
  
  char *hostname;
  char *port_number;
  char peticion[MAX_SIZE_BUFFER];

  /*select*/
  fd_set readset; /* leera el conjunto de descriptores de archivos */
  int num_ready;
  int num_now;
  int num_fds;

  /* control de hora */
  time_t hora1,hora2;
  struct tm *hora_entrada;
  struct tm *hora_salida;
  
  
  /* comprobacion de argumentos */
   if (argc < 2) {
        perror ("Error en el paso de parametros.\n");
        exit (1);
   }
                                                                                                                 
   /* apertura del fichero */
    if((log_file = fopen ("log.txt", "r"))<0) {
        perror("Error abriendo el fichero\n");
        exit(-1);
    }

    /* reservamos memoria para el hostname y el puerto */
    hostname=(char *)malloc(sizeof(hostname));
    port_number=(char *)malloc(sizeof(port_number));

    i=0;
    
    /* buscamos los servidores en el fichero */
    while (fscanf (log_file, "%s\t %s \n", hostname, port_number) != EOF) {
        puerto = atoi (port_number);
        j=2;/* iniciamos a 2 para olvidarnos del nombre de programa y la peticion */
        encontrado=0;/* iniciamos la variable */
        while ((j<=argc)&(encontrado==0)) {
            if (strcmp(hostname,argv[j])==TRUE) {
                encontrado=1;/* marcamos como encontrado */
                puertos[i]=puerto;/* metemos el puerto en el vector de puertos */
                i++;
            }
            j++;
        }
    }

    /* no se encuentran servidores */
    if (i==0) {
        perror("No se ha encontrado ningun servidor activo que corresponda a los introducidos\n");
        exit(1);
    }
      
    max=max/i; /* dividimos entre los disponibles el numero m�ximo para repartirlo */
    intervalo=max; /* este sera el intervalo */
    
  /* estructura del host en he */
  if ((he = gethostbyname (local)) == NULL) {
      /* llamada a gethostbyname() */
      printf ("gethostbyname() error\n");
      exit (-1);
  }

  /*SELECT*/
  num_fds=i;/* numero de descriptores = numero de servidores */
  num_now=num_fds;
  
  printf("Pulse ENTER para conectar...\n");
  
  while (num_now > 0) {
      /* limpiamos el valor de set */
      FD_ZERO(&readset);

      for (j=0;j<num_fds;j++) {
        fd[j]=j;
        if (fd[j]>=0) {
            /* a�adimos el descriptor a set */
            FD_SET(fd[j],&readset);
        }
      }
      
     /* select necesita el descriptor de archivos maximo */
      if ((num_ready = select(MAX_FD,&readset,NULL,NULL,NULL)) == -1) {
          perror("Error en select\n");
          exit(1);
      }
      printf("Servidores disponibles: %d", num_ready);
      
      /* hora de entrada */
      time(&hora1);
      hora_entrada=localtime(&hora1);
      printf("\tHora de comienzo:  %d:%d:%d\n",hora_entrada->tm_hour,hora_entrada->tm_min,hora_entrada->tm_sec);

      for (j=0;j<num_fds && num_ready>0;j++) {
        /* si hay descriptor y esta establecido en set */
        if ((fd[j]>=0) && FD_ISSET(fd[j],&readset)) {
            
            /* socket() */
            if ((fd[j] = socket (AF_INET, SOCK_STREAM, 0)) == -1) {
                printf ("socket() error\n");
                exit (-1);
            }

            server.sin_family = AF_INET;
            server.sin_port = htons (puertos[j]);/* htons() es necesaria nuevamente ;-o */
            server.sin_addr = *((struct in_addr *) he->h_addr); /*he->h_addr pasa la informaci�n de *he a "h_addr" */
            bzero (&(server.sin_zero), 8);

            /* connect() */
            if (connect (fd[j], (struct sockaddr *) &server, sizeof (struct sockaddr)) == -1) {
                printf ("connect() error\n");
                exit (-1);
            }
   
            printf ("Mandando datos al servidor...\n");

            strcpy(peticion,argv[1]);

            /* mandamos al servidor la peticion */
            if (numbytes = write (fd[j], peticion, MAX_SIZE_BUFFER) == -1) {
                perror ("Env�o de la peticion.\n");
                exit (1);
            }
  
            /* mandamos al servidor el valor minimo del intervalo */
            if (numbytes = write (fd[j], &min, sizeof (long)) == -1) {
                perror ("Env�o del m�nimo.\n");
                exit (1);
            }
  
            /* mandamos al servidor el valor maximo del intervalo */
            if (numbytes = write (fd[j], &max, sizeof (long)) == -1) {
                perror ("Env�o del maximo.\n");
                exit (1);
            }
                                    
            if ((strcmp(peticion,"cuenta_primos"))==TRUE) {
            /* recibimos la respuesta del servidor con el numero de primos */
            if ((numbytes = read(fd[j], &num_primos, sizeof (long))) == -1) {
                perror ("Error en revc\n");
                exit (1);
            }

            num_ready--; /* atendida y por tanto uno menos disponible */
  
            printf ("El numero de primos que me ha mandao el servidor es: %d\n", num_primos);

            /* actualizamos valores */
            numero+=num_primos;
            min=max;
            max+=intervalo;

            num_now--;

            /* hora de salida */
            time(&hora2);
            hora_salida=localtime(&hora2);
            printf("\tHora de finalizacion: %d:%d:%d\n",hora_salida->tm_hour,hora_salida->tm_min,hora_salida->tm_sec);
            fflush(stdout);
            fd[j]=-1;
            /* si la peticion es devolver el vector de primos */
            } else if ((strcmp(peticion,"encuentra_primos"))==TRUE) {
               /* recibimos la longitud del vector de primos */
                if ((numbytes = read(fd[j], &longitud, sizeof (long))) == -1) {
                    perror ("Error en revc\n");
                    exit (1);
                }
                
                printf("La lista de primos obtenida del servidor es: ");

                /* recogemos la lista de primos que nos manda el servidor */
                for (i=0;i<longitud;i++) {
                    if ((numbytes = read(fd[j],&buffer[i],sizeof(long))) == -1) {
                        perror("Error recibiendo la lista de primos\n");
                        exit(1);
                    }
                    printf(" %d ", buffer[i]);
                }
                printf("\n");
                num_ready--;
                num_now--;
                fd[j]=-1;
            } else {
                printf("No existe esa opcion\n");
                exit(1);
            }
        }
      }
  }
  close(fd[j]);
  free(hostname);
  free(port_number);
}
