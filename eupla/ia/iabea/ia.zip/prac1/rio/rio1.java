import java.io.*;
import java.util.*;

/* Soluci�n al problema del hombre, el lobo, la obeja, la lechuga*/

class Estado {
			boolean h,l,o,x;		// Indica el lugar de cada uno de los seres. Si est�n a false
													// no se encuentran en la orilla objetivo.
			Estado(){		// Constructor 1
				h=false;		//hombre
				l=false;		//lobo
				o=false;		//oveja
				x=false;		//lechuga
			}

			Estado(boolean h,boolean l,boolean o,boolean x){		// Constructor 2 
				this.h=h;
				this.l=l;
				this.o=o;
				this.x=x;
			}

			Estado pasar_lobo(){	  //Debe cumplir este movimiento unas cuantas condiciones para poder pasar
			//	1.- El lobo y el hombre est�n en la misma orilla.
					if (h==l){
					// La oveja y la lechuga no pueden estar en la misma orilla
					if(o!=x){
							// Ya puede pasar...
							if(h==true){
									Estado nestado = new Estado(false,false,o,x);
									return nestado;
							}
							else {
									Estado nestado = new Estado(true,true,o,x);
									return nestado;
							}
						}
						else return(null);					
					}
					else return(null);
			}
			
			Estado pasar_oveja(){			
			// Para poder pasar a la oveja, se tendr�n que cumplir algunas condiciones.
			//	1.- Que la oveja y el hombre est�n en la misma orilla.
					if (h==o){
							// Ahora la podemos pasar...
							if(h==true){
									Estado nestado = new Estado(false,l,false,x);	
									return nestado;
							}
							else {
									Estado nestado = new Estado(true,l,true,x);				
									return nestado;
							}
					}
					else return(null);				
			}

			Estado pasar_lechuga(){
			// Para poder pasar a la lechuga, se tendr�n que cumplir algunas condiciones.
			//	1.- Que la leghuga y el hombre est�n en la misma orilla.
					if (h==x){
					// 2.- Que no dejemos al lobo y a la oveja juntos...
						if(l!=o){
							// Ahora la podemos pasar...
							if(h==true){
									Estado nestado = new Estado(false,l,o,false);	
									return nestado;
							}
							else {
									Estado nestado = new Estado(true,l,o,true);									
									return nestado;
							}
						}
						else return(null);					
					}
					else return(null);				
			}
			
			Estado pasar_de_vacio(){
			// Para poder pasar de vacio, se tendr�n que cumplir algunas condiciones.
			//	1.- Que el lobo y la oveja no est�n en la misma orilla.
					if (l!=o){
					// 2.- Que no dejemos la lechuga y a la oveja juntos...
						if(x!=o){
							// Ahora la podemos pasar...
							if(h==true){
									Estado nestado = new Estado(false,l,o,x);	
									return nestado;
							}
							else {
									Estado nestado = new Estado(true,l,o,x);	
									return nestado;
							}
						}
						else return(null);					
					}
					else return(null);				
			}
			
			void describe(){
					System.out.println("Estado actual: h " + h + " l " + l + " o " + o + " x " + x);	
			}
}

public class rio1{
	
	public static void main(String[] args){
		
		Estado el_estado;
		
		el_estado = new Estado(false,false,false,false); //inicializar variables. False en orilla inicio y True 
																													//en orilla destino.
		el_estado.describe();	
		el_estado = el_estado.pasar_oveja();
		el_estado.describe();
		el_estado = el_estado.pasar_de_vacio();
		el_estado.describe();
		el_estado = el_estado.pasar_lobo();
		el_estado.describe();
		el_estado = el_estado.pasar_oveja();
		el_estado.describe();
		el_estado = el_estado.pasar_lechuga();
		el_estado.describe();
		el_estado = el_estado.pasar_de_vacio();
		el_estado.describe();
		el_estado = el_estado.pasar_oveja();
		el_estado.describe();
	}	
}