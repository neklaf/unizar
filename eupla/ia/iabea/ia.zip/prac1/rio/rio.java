import java.io.*;
import java.util.*;

/* Soluci�n al problema del hombre, el lobo, la obeja, la lechuga*/

class Estado {
			boolean h,l,o,x;		//variables para la comprobacion de donde se encuentra cada elemento.
													//si false--> esta en orillaB
													//si true--> esta en orillaA
			int i;
			Vector orillaA = new Vector();
			Vector orillaB = new Vector();
			char aux[]={'h','l','o','x'};
		  char aux2[]={};
			
			Estado(){
					for (i=0;i<4;i++){
						String valor=new String(aux, i, 1);
						orillaB.add(valor);
					}
			}

			Estado(Vector orillaA, Vector orillaB){		// Constructor 2 
				this.orillaA=orillaA;
				this.orillaB=orillaB;
			}

			Estado pasar_lobo(){	  
				System.out.println("\nPASAR EL LOBO");
				//PRIMERO COMPROBAR EN QUE ORILLA ESTA CADA ELEMENTO POR SI SE CUMPLEN LAS CONDICIONES PARA EL MOVIMIENTO
				for (i=0;i<orillaA.size();i++) 
				{
					if (orillaA.elementAt(i).equals("h")) h=true;
					if (orillaA.elementAt(i).equals("o")) o=true;
					if (orillaA.elementAt(i).equals("x")) x=true;
					if (orillaA.elementAt(i).equals("l")) l=true;
				}
				for (i=0;i<orillaB.size();i++)
				{
					if (orillaB.elementAt(i).equals("h")) h=false;
					if (orillaB.elementAt(i).equals("o")) o=false;
					if (orillaB.elementAt(i).equals("x")) x=false;
					if (orillaB.elementAt(i).equals("l")) l=false;
				} 

			//Debe cumplir este movimiento unas cuantas condiciones para poder pasar
			//El lobo y el hombre deben estar en la misma orilla.
					if (h==l){
					// La oveja y la lechuga no pueden estar en la misma orilla
					if(o!=x){
							// Ya puede pasar...
							if(h==true){
									String valor = new String("l");
									orillaB.add(valor);
									orillaA.remove(valor);
									valor = new String("h");
									orillaB.add(valor);
									orillaA.remove(valor);
									Estado nestado = new Estado(orillaA, orillaB);	
									return nestado;
							}
							else {
									String valor = new String("l");
									orillaA.add(valor);
									orillaB.remove(valor);
									valor = new String("h");
									orillaA.add(valor);
									orillaB.remove(valor);
									Estado nestado = new Estado(orillaA, orillaB);	
									return nestado;
							}
						}
						else return(null);					
					}
					else return(null);
			}
			
			Estado pasar_oveja(){			
				System.out.println("\nPASAR OVEJA");
				//PRIMERO COMPROBAR EN QUE ORILLA ESTA CADA ELEMENTO POR SI SE CUMPLEN LAS CONDICIONES PARA EL MOVIMIENTO
				for (i=0;i<orillaA.size();i++) 
				{
					if (orillaA.elementAt(i).equals("h")) h=true;
					if (orillaA.elementAt(i).equals("o")) o=true;
					if (orillaA.elementAt(i).equals("x")) x=true;
					if (orillaA.elementAt(i).equals("l")) l=true;
				}
				for (i=0;i<orillaB.size();i++)
				{
					if (orillaB.elementAt(i).equals("h")) h=false;
					if (orillaB.elementAt(i).equals("o")) o=false;
					if (orillaB.elementAt(i).equals("x")) x=false;
					if (orillaB.elementAt(i).equals("l")) l=false;
				} 
				// Condiciones que se han de cumplir para que pueda pasar la oveja
				//La oveja y el hombre deben estar en la misma orilla.
				if (h==o){
						// Ahora la podemos pasar...
						if(h==true){
									String valor = new String("o");
									orillaB.add(valor);
									orillaA.remove(valor);
									valor = new String("h");
									orillaB.add(valor);
									orillaA.remove(valor);
									Estado nestado = new Estado(orillaA, orillaB);	
									return nestado;
							}
							else {
									String valor = new String("o");
									orillaA.add(valor);
									orillaB.remove(valor);
									valor = new String("h");
									orillaA.add(valor);
									orillaB.remove(valor);
									Estado nestado = new Estado(orillaA, orillaB);	
									return nestado;
							}
					}
					else return(null);				
			}

			Estado pasar_lechuga(){
				System.out.println("\nPASAR LECHUGA");
			//PRIMERO COMPROBAR EN QUE ORILLA ESTA CADA ELEMENTO POR SI SE CUMPLEN LAS CONDICIONES PARA EL MOVIMIENTO
				for (i=0;i<orillaA.size();i++) 
				{
					if (orillaA.elementAt(i).equals("h")) h=true;
					if (orillaA.elementAt(i).equals("o")) o=true;
					if (orillaA.elementAt(i).equals("x")) x=true;
					if (orillaA.elementAt(i).equals("l")) l=true;
				}
				for (i=0;i<orillaB.size();i++)
				{
					if (orillaB.elementAt(i).equals("h")) h=false;
					if (orillaB.elementAt(i).equals("o")) o=false;
					if (orillaB.elementAt(i).equals("x")) x=false;
					if (orillaB.elementAt(i).equals("l")) l=false;
				} 

			// Para poder pasar a la lechuga, se tendr�n que cumplir algunas condiciones.
			//La leghuga y el hombre deben estar en la misma orilla.
					if (h==x){
					//El lobo y a la oveja no pueden estar en la misma orilla...
					if(l!=o){
							// Ahora la podemos pasar...
							if(h==true){
									String valor = new String("x");
									orillaB.add(valor);
									orillaA.remove(valor);
									valor = new String("h");
									orillaB.add(valor);
									orillaA.remove(valor);
									Estado nestado = new Estado(orillaA, orillaB);	
									return nestado;
							}
							else {
									String valor = new String("x");
									orillaA.add(valor);
									orillaB.remove(valor);
									valor = new String("h");
									orillaA.add(valor);
									orillaB.remove(valor);
									Estado nestado = new Estado(orillaA, orillaB);	
									return nestado;
							}
						}
						else return(null);					
					}
					else return(null);				
			}
			
			Estado pasar_de_vacio(){
				System.out.println("\nPASAR DE VACIO");
				//PRIMERO COMPROBAR EN QUE ORILLA ESTA CADA ELEMENTO POR SI SE CUMPLEN LAS CONDICIONES PARA EL MOVIMIENTO
				for (i=0;i<orillaA.size();i++) 
				{
					if (orillaA.elementAt(i).equals("h")) h=true;
					if (orillaA.elementAt(i).equals("o")) o=true;
					if (orillaA.elementAt(i).equals("x")) x=true;
					if (orillaA.elementAt(i).equals("l")) l=true;
				}
				for (i=0;i<orillaB.size();i++)
				{
					if (orillaB.elementAt(i).equals("h")) h=false;
					if (orillaB.elementAt(i).equals("o")) o=false;
					if (orillaB.elementAt(i).equals("x")) x=false;
					if (orillaB.elementAt(i).equals("l")) l=false;
				} 
				
			// Para poder pasar de vacio, se tendr�n que cumplir algunas condiciones.
			//	1.- Que el lobo y la oveja no est�n en la misma orilla.
					if (l!=o){
					// 2.- Que no dejemos la lechuga y a la oveja juntos...
						if(x!=o){
							// Ahora la podemos pasar...
							if(h==true){
									String valor = new String("h");
									orillaB.add(valor);
									orillaA.remove(valor);
									Estado nestado = new Estado(orillaA, orillaB);	
									return nestado;
							}
							else {
									String valor = new String("h");
									orillaA.add(valor);
									orillaB.remove(valor);
									Estado nestado = new Estado(orillaA, orillaB);	
									return nestado;
							}
						}
						else return(null);					
					}
					else return(null);				
			}
			
			void describe(){
					System.out.println("\nORILLA A:");	
					for (i=0;i<orillaA.size();i++) System.out.print(orillaA.elementAt(i));
					System.out.println("\nORILLA B:");	
					for (i=0;i<orillaB.size();i++) System.out.print(orillaB.elementAt(i));

			}
}

public class rio{
	
	public static void main(String[] args){
		
		Estado el_estado;
		
		System.out.println("INICIO PRACTICA RIO");
		el_estado = new Estado(); //Inicializar orilla origen(A) y orilla destino(B)
		el_estado.describe();	
		el_estado = el_estado.pasar_oveja();
		el_estado.describe();
		el_estado = el_estado.pasar_de_vacio();
		el_estado.describe();
		el_estado = el_estado.pasar_lobo();
		el_estado.describe();
		el_estado = el_estado.pasar_oveja();
		el_estado.describe();
		el_estado = el_estado.pasar_lechuga();
		el_estado.describe();
		el_estado = el_estado.pasar_de_vacio();
		el_estado.describe();
		el_estado = el_estado.pasar_oveja();
		el_estado.describe();
	}	
}