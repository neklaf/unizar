import java.io.*;
import java.util.*;

/*  PROBLEMA DE 2 GARRAFAS DE 3 Y 4 LITROS Y EN UNA DE ELLAS HA DE QUEDARSE 2 LITROS
    SE DISPONE DE DOS GARRAFAS DE 3 Y 4 LITROS, ADEMAS DE UNA CANTIDAD ILIMITADA DE AGUA.
    EL OBJETIVO ES LOGRAR UNA MEDIDA DE 2 LITROS EN CUALQUIERA DE LAS DOS GARRAFAS. SE PUEDE 
    CONSEGUIR CON LAS OPERACIONES: LLENAR GARRAFA 3, LLENAR GARRAFA 4, VACIAR LA 3, VACIAR LA 4, ECHAR DE 3 A 4 Y VICEVERSA.

    UN CASO DE COMO SE PODRIA CONSEGUIR, ES: 
		*LLENAR GARRAFA 4, PASAR DE 4 A 3 Y QUEDARIA UN LITRO EN LA DE 4, VACIAR
		 LA DE 3 Y PASAR EL LITRO DE 4 A 3, Y LLENAR LA DE 4 Y PASAR HASTA LLENAR 
		 LA DE 3 Y ENTONCES QUEDAN 2 LITROS EN LA DE 4.*/


class Estado 
{
			int g3, g4;		// garrafa 3 y 4 y su valor es el agua que contienen
			Estado()
			{		
				g3=0;				// LAS INICIALIZAMOS A CERO
				g4=0;
			}

			Estado(int g3, int g4)
			{			
				this.g3=g3;								// CONSTRUCTOR PARA ASIGNARLES EL VALOR
				this.g4=g4;
			}

			// Operaciones aplicables sobre un estado
			// Si son aplicables devuelven el nuevo estado, si son imposibles, devuelven
			// null

//LAS OPERACIONES APLICABLES, SON: LLENAR4, ECHAR 4->3, VACIAR3
//LAS OTRAS OPERACIONES SERIAN: LLENAR 3, ECHAR 3->4, VACIAR 4

			Estado llenar4()						//PROCEDIMIENTO PARA LLENAR LA GARRAFA DE 4 LITROS
			{
			System.out.println("LLENAR GARRAFA 4");	
				if (g4<4)
				{
				  Estado nestado = new Estado(g3, 4);
				  return nestado;
				}
				else return (null);
			}
			
			Estado llenar3()
			{
			System.out.println("LLENAR GARRAFA 3");	
				if (g3<3)
				{
				  Estado nestado = new Estado(3, g4);
				  return nestado;
				}
				else return (null);
			}

			Estado echar3_4()
			{

			System.out.println("ECHAR DE GARRAFA 3 A GARRAFA 4");	
			 if (g3>0)
			 {
			  if (g4<4)
			  {
			    if (g3+g4>=4)
			    {
				  Estado nestado = new Estado(g3-(4-g4), 4); 
				  return nestado;
			    }
			    else 
			    {
				  Estado nestado = new Estado(0, g4+g3); 
				  return nestado;
			    }
			  }
			  else return (null);
			 }
			 else return (null);
			}
				
			Estado echar4_3()
			{

			System.out.println("ECHAR DE GARRAFA 4 A GARRAFA 3");	
			 if (g4>0)
			 {
			  if (g3<3)
			  {
			    if (g3+g4>=3)
			    {
				  Estado nestado = new Estado(3, g4-(3-g3)); 
				  return nestado;
			    }
			    else 
			    {
				  Estado nestado = new Estado(g3+g4, 0); 
				  return nestado;

			    }
			  }
			  else return (null);
			 }
			 else return (null);
			}

			Estado vaciar4()
			{
			  //para poder vaciar la garrafa4, g4 ha de tener algun litro.

			System.out.println("VACIAR GARRAFA 4");	
			if (g4>0)
				{
				  Estado nestado = new Estado(g3, 0);
				  return nestado;
				}
				else return (null);
			}

			Estado vaciar3()
			{
			  //para poder vaciar la garrafa3, g3 ha de tener algun litro.
			System.out.println("VACIAR GARRAFA 3");	
				if (g3>0)
				{
				  Estado nestado = new Estado(0, g4);
				  return nestado;
				}
				else return (null);
			}

			void describe(){
					System.out.println("Estado actual: G3L " + g3 + " G4L " + g4);	
			}
}

public class garrafas1_2{


	public static void main(String[] args){
		
		Estado el_estado;
		
		// Estado inicial
		el_estado = new Estado(0, 0); //pongo las 2 garrafas vacias
		el_estado.describe();
		el_estado = el_estado.llenar3();
		el_estado.describe();
		el_estado = el_estado.echar3_4();
		el_estado.describe();
		el_estado = el_estado.llenar3();
		el_estado.describe();
		el_estado = el_estado.echar3_4();
		el_estado.describe();


		

	
		/*el_estado = el_estado.llenar4();
		el_estado.describe();
		el_estado = el_estado.echar4_3();
		el_estado.describe();
		el_estado = el_estado.vaciar3();
		el_estado.describe();
		el_estado = el_estado.echar4_3();
		el_estado.describe();
		el_estado = el_estado.llenar4();
		el_estado.describe();
		el_estado = el_estado.echar4_3();
		el_estado.describe();*/
	}	
}