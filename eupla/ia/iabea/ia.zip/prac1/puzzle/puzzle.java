import java.io.*;
import java.util.*;

/*PROBLEMA DEL 8-PUZZLE
		2 vectores que son los 2 tableros inicial y final.
		Se siguen los movimientos arriba, abajo, derecha, izquierda para encontrar una solucion*/

//PONER SOLUCION QUE ES LA QUE SOLUCIONA EL PROBLEMA

class Estado 
{
			Vector estini=new Vector();				// VECTOR DE VALORES INICIALES
		  Vector estfin=new Vector();				// VECTOR DE VALORES FINALES
		  Vector mov=new Vector();					// VECTOR DE MOVIMIENTOS
		  	
		  int i;
		  int aux[]={2,3,4,1,9,6,8,7,5};
		  int aux2[]={1,2,3,8,9,4,7,6,5};
		  
		  
		  // CONSTRUCTOR PARA INICIALIZAR LOS VECTORES INICIO, FINAL Y EL DE MOVIMIENTOS
		  
		  Estado(){
				for (i=0;i<9;i++)
				{
					Integer valor=new Integer(aux[i]);
					estini.add(valor);
					Integer valor2=new Integer(aux2[i]);
					estfin.add(valor2);
					Integer valor3=new Integer(aux[i]);
					mov.add(valor3);

				}
			}
			
			// CONSTRUCTOR QUE CAMBIA EL VECTOR QUE GUARDA TODOS LOS MOVIMIENTOS
			
		Estado(Vector mov)				
		{
			this.mov=mov;
		}
		

			/*OPERACIONES APLICABLES SOBRE EL TABLERO:MOVER ARRIBA, MOVER ABAJO, MOVER DERECHA, MOVER IZQUIERDA*/
			
			
			// PROCEDIMIENTO PARA MOVER ABAJO, VALOR ES EL NUMERO QUE VAMOS A MOVER E INDICE LA POSICION DESTINO
			
			Estado moverarriba(Integer valor, int indice)
			{
			System.out.println("MOVER ARRIBA");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice+3);
			Integer blanco = new Integer(9);
			mov.add(indice+3, blanco);
			Estado nestado=new Estado(mov);
			return nestado;

			}
			
			
			// PROCEDIMIENTO PARA MOVER ABAJO
			
			Estado moverabajo(Integer valor, int indice)
			{
			System.out.println("MOVER ABAJO");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice-3);
			Integer blanco = new Integer(9);
			mov.add(indice-3, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}


			// PROCEDIMIENTO PARA MOVER A LA DERECHA
			
			Estado moverderecha(Integer valor, int indice)
			{
			System.out.println("MOVER DERECHA");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice-1);
			Integer blanco = new Integer(9);
			mov.add(indice-1, blanco);
			Estado nestado=new Estado(mov);
			return nestado;

			}				
			
			
			// PROCEDIMIENTO PARA MOVER A LA IZQUIERDA
			
			Estado moverizqda(Integer valor, int indice)
			{
			System.out.println("\nMOVER IZQUIERDA");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice+1);
			Integer blanco = new Integer(9);
			mov.add(indice+1, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}
			
			
			// PROCEDIMIENTO PARA SACAR POR PANTALLA
			
			void describe(){
					System.out.println("\nTablero de movimientos:");	
					for(i=0;i<9;i++) System.out.print(mov.elementAt(i));
			}
}



					// PROCEDIMIENTO PRINCIPAL
					
public class puzzle{


	public static void main(String[] args){
		
		Estado el_estado;
				
		// ESTADO INICIAL
		
		System.out.println("INICIO 8-PUZZLE");
		el_estado = new Estado(); 											// SE INICIALIZAN LOS TABLEROS
		el_estado.describe();
		
		Integer valor =new Integer(6);
		el_estado = el_estado.moverizqda(valor, 4);   // MOVEMOS EL 6 A LA 4
		el_estado.describe();
		
		valor =new Integer(4);
		el_estado = el_estado.moverabajo(valor, 5);		// MOVEMOS EL 4 EN LA 5
		el_estado.describe();

		valor =new Integer(3);
		el_estado = el_estado.moverderecha(valor, 2);	// MOVEMOS EL 3 EN LA 2
		el_estado.describe();

		valor =new Integer(2);
		el_estado = el_estado.moverderecha(valor, 1);	// MOVEMOS EL 2 EN LA 1
		el_estado.describe();

		valor =new Integer(1);
		el_estado = el_estado.moverarriba(valor, 0);		// MOVEMOS EL 1 EN LA 0
		el_estado.describe();
		
		valor =new Integer(8);
		el_estado = el_estado.moverarriba(valor, 3);		// MOVEMOS EL 8 EN LA 3
		el_estado.describe();

		valor =new Integer(7);
		el_estado = el_estado.moverizqda(valor, 6);		// MOVEMOS EL 7 EN LA 6
		el_estado.describe();
		
		valor =new Integer(6);
		el_estado = el_estado.moverabajo(valor, 7);		// MOVEMOS EL 6 EN LA 7
		el_estado.describe();


		
	}	
}