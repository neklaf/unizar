import java.io.*;
import java.util.*;
//import java.util.Vector;
import java.lang.*;

/*PROBLEMA DEL CABALLO*/

class Estado 
{
			Vector estini=new Vector();   // VECTOR DONDE GUARDAMOS LOS VALORES INICIALES
		  Vector estfin=new Vector();		// VECTOR DONDE ESTAN LOS VALORES FINALES
		  Vector mov=new Vector();			// VECTOR DE MOVIMIENTOS
		  
		  
		  int i;																										// VARIABLE CONTADOR
		  char aux[]={'b','b','b','9','9','9','n','n','n'};			//INICIALIZAMOS LOS VECTORES AUXILIARES
		  char aux2[]={'n','n','n','9','9','9','b','b','b'};
		  
		  Estado(){
				for (i=0;i<9;i++)																			//CONSTRUCTOR QUE INICIALIZA LOS VECTORES
				{																													// INICIO Y FIN
					String valor=new String(aux, i, 1);
					estini.add(valor);
					String valor2=new String(aux2, i, 1);
					estfin.add(valor2);
					String valor3=new String(aux, i, 1);
					mov.add(valor3);

				}
			}
																
		Estado(Vector mov)          // CONSTRUCTOR QUE CAMBIA EL VECTOR QUE GUARDA TODOS LOS MOVIMIENTOS
		{
			this.mov=mov;
		}
		
		
			// PROCEDIMIENTO PARA CAMBIAR LA POSICION EN UNO
			

			Estado moveruno(String valor, int indice)    
			{
			System.out.println("MOVER UNO");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice-1);
			String blanco = new String("9");
			mov.add(indice-1, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}
			
			
			// PROCEDIMIENTO PARA CAMBIAR LA POSICION EN DOS
			
			
			Estado moverdos(String valor, int indice)		
			{
			System.out.println("MOVER DOS");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice+1);
			String blanco = new String("9");
			mov.add(indice+1, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}


			// PROCEDIMIENTO PARA CAMBIAR LA POSICION EN TRES
				
			
			Estado movertres(String valor, int indice)		
			{
			System.out.println("MOVER TRES");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice+5);
			String blanco = new String("9");
			mov.add(indice+5, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}
			
			
			// PROCEDIMIENTO PARA CAMBIAR LA POSICION EN CUATRO
			
			
			Estado movercuatro(String valor, int indice)		
			{
			System.out.println("MOVER CUATRO");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice-7);
			String blanco = new String("9");
			mov.add(indice-7, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}

			
			// PROCEDIMIENTO PARA CAMBIAR LA POSICION EN CINCO
			
			
			Estado movercinco(String valor, int indice)		
			{
			System.out.println("MOVER CINCO");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice+5);
			String blanco = new String("9");
			mov.add(indice+5, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}


			// PROCEDIMIENTO PARA CAMBIAR LA POSICION EN SEIS
			

			Estado moverseis(String valor, int indice)		
			{
			System.out.println("MOVER SEIS");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice-5);
			String blanco = new String("9");
			mov.add(indice-5, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}


			// PROCEDIMIENTO PARA CAMBIAR LA POSICION EN SIETE
			

			Estado moversiete(String valor, int indice)		
			{
			System.out.println("MOVER SIETE");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice+7);
			String blanco = new String("9");
			mov.add(indice+7, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}


			// PROCEDIMIENTO PARA CAMBIAR LA POSICION EN OCHO


			Estado moverocho(String valor, int indice)		
			{
			System.out.println("MOVER OCHO");	
			mov.remove(indice);
			mov.add(indice, valor);
			mov.remove(indice-5);
			String blanco = new String("9");
			mov.add(indice-5, blanco);
			Estado nestado=new Estado(mov);
			return nestado;
			}


			// PROCEDIMIENTO PARA SACAR POR PANTALLA

			
			void describe(){														
					System.out.println("\nTablero de movimientos:");	
					for(i=0;i<9;i++) System.out.print(mov.elementAt(i));
			}
}

public class caballo{							// PROCEDIMIENTO PRINCIPAL


	public static void main(String[] args){
		
		Estado el_estado;
				
		// ESTADO INICIAL
		
		System.out.println("INICIO CABALLO");
		el_estado = new Estado(); 											// INICIALIZAMOS LOS TABLEROS
		el_estado.describe();
		
		
		// EMPEZAMOS A MOVER PASAMOS SIEMPRE EL DESTINO DE LA FICHA
		
		
		String valor=new String("b");										// MOVEMOS LA PRIMERA FICHA, LA 2 EN LA 3
		el_estado = el_estado.moveruno(valor, 3);
		el_estado.describe();

		valor=new String("n");														// MOVEMOS LA SEGUNDA FICHA, LA 6 EN LA 5
		el_estado = el_estado.moverdos(valor, 5);
		el_estado.describe();

		valor=new String("n");												
		el_estado = el_estado.movertres(valor, 2);			// MOVEMOS LA TERCERA FICHA, LA 7 EN LA 2
		el_estado.describe();
				
		valor=new String("b");
		el_estado = el_estado.movercuatro(valor, 7);		// MOVEMOS LA CUARTA FICHA, LA 0 EN LA 7
		el_estado.describe();

		valor=new String("n");
		el_estado = el_estado.movercinco(valor, 0);		// MOVEMOS LA QUINTA FICHA, LA 5 EN LA 0
		el_estado.describe();

		valor=new String("b");
		el_estado = el_estado.moverseis(valor, 6);			// MOVEMOS LA SEXTA FICHA, LA 1 EN LA 6
		el_estado.describe();

		valor=new String("n");
		el_estado = el_estado.moversiete(valor, 1);		// MOVEMOS LA SEPTIMA FICHA, LA 8 EN LA 1
		el_estado.describe();

		valor=new String("b");
		el_estado = el_estado.moverocho(valor, 8);			// MOVEMOS LA OCTAVA FICHA, LA 3 EN LA 8
		el_estado.describe();


		
	}	
}