import java.io.*;
import java.util.*;

class Nodo{
				Estado este;
				
				Nodo(Estado pest){		// Constructor del nodo a partir de un estado.
				 este = new Estado(pest.mov,pest.padre,pest.profundidad);
				}

			  //Crea un vector de estados que se van a expandir a partir del actual
			  Vector Expandir(Estado e){
							int pr,i, indice;
							Integer blanco=new Integer(9);
							Vector nuevos = new Vector();	
							Vector auxiliar=new Vector();
							Vector auxiliar2=new Vector();
							Estado aux;
							Integer num;
							auxiliar=(Vector)e.mov.clone(); //creo un clone del vector para que si modifico
							                                //valores en auxiliar no se modifiquen en e.mov							                           
							auxiliar2=(Vector)auxiliar.clone(); //vector auxiliar por si hay cambios en auxiliar.
							indice=e.buscablanco();
						  //System.out.println("Indice encontrado en este estado: "+indice);  
						  //System.out.println("Profundidad en expandir: "+e.profundidad);  
						    //hace movimiento mover arriba
						    if (indice!=-1) //si no ha habido fallo buscando el blanco en este estado
			  				{	
						    	if ((indice>=0)&&(indice<=5)) //si se puede hacer el mvto hacia arriba
						    	{
						     	auxiliar=(Vector)auxiliar2.clone();
						    	num=(Integer)auxiliar.elementAt(indice+3);
			    				auxiliar.removeElementAt(indice);
               	auxiliar.insertElementAt(num,indice);
			          	auxiliar.removeElementAt(indice+3);
			          	auxiliar.insertElementAt(blanco,indice+3);
	               //System.out.println("Vector auxiliar despues de moverarriba: "+auxiliar);
						    	pr=e.profundidad+2;					
						    	aux=new Estado(auxiliar,null,pr-1);
						    	aux.padre = this;
						    	nuevos.addElement(aux);
						    	}
			  				}
						    else System.out.println("ERROR LOCALIZANDO EL BLANCO en mover arriba");
						    
						    
						    //hace movimiento mover abajo
						    if (indice!=-1) //si no ha habido fallo buscando el blanco en este estado
			  				{		
						    	if ((indice>=3)&&(indice<=8)) //si se puede hacer el mvto hacia abajo
						    	{
						    	auxiliar=(Vector)auxiliar2.clone();
						    	num=(Integer)auxiliar.elementAt(indice-3);
			    				auxiliar.removeElementAt(indice);
               	auxiliar.insertElementAt(num,indice);
			          	auxiliar.removeElementAt(indice-3);
			          	auxiliar.insertElementAt(blanco,indice-3);
               	//System.out.println("Vector auxiliar despues de moverabajo: "+auxiliar);
						    	pr=e.profundidad+2;					
						    	aux=new Estado(auxiliar,null,pr-1);
						    	aux.padre = this;
						    	nuevos.addElement(aux);
						    	}
			  				}
						    else System.out.println("ERROR LOCALIZANDO EL BLANCO en mover abajo");
						    
						    
						    //hace movimiento mover derecha
						    if (indice!=-1) //si hay blanco
			  				{
			  					if ((indice!=0)&&(indice!=3)&&(indice!=6)) //si se puede hacer el mvto hacia la derecha
						    	{
						    	auxiliar=(Vector)auxiliar2.clone();
						    	num=(Integer)auxiliar.elementAt(indice-1);
			    				auxiliar.removeElementAt(indice);
               	auxiliar.insertElementAt(num,indice);
			          	auxiliar.removeElementAt(indice-1);
			          	auxiliar.insertElementAt(blanco,indice-1);
               	//System.out.println("Vector auxiliar despues de moverderecha: "+auxiliar);
						    	pr=e.profundidad+2;					
						    	aux=new Estado(auxiliar,null,pr-1);
						    	aux.padre = this;
						    	nuevos.addElement(aux);
						    	}
			  				}
						    else System.out.println("ERROR LOCALIZANDO EL BLANCO en mover derecha");

								//hace movimiento mover izquierda
								if (indice!=-1) //si hay blanco
			  				{
			  					if ((indice!=2)&&(indice!=5)&&(indice!=8)) //si se puede hacer el mvto hacia la derecha
						    	{
						    	auxiliar=(Vector)auxiliar2.clone();
						    	num=(Integer)auxiliar.elementAt(indice+1);
			    				auxiliar.removeElementAt(indice);
               	auxiliar.insertElementAt(num,indice);
			          	auxiliar.removeElementAt(indice+1);
			          	auxiliar.insertElementAt(blanco,indice+1);
               	//System.out.println("Vector auxiliar despues de moverizquierda: "+auxiliar);
						    	pr=e.profundidad+2;					
						    	aux=new Estado(auxiliar,null,pr-1);
						    	aux.padre = this;
						    	nuevos.addElement(aux);
						    	}
			  				}
						    else System.out.println("ERROR LOCALIZANDO EL BLANCO en mover izquierda");


						    
						    return nuevos;
				}//Exapandir
									
			 		
				//Describe un estado , generalmente el actual	
				void describe(){
					System.out.println("Nodo actual:");
					este.describe();
				}				
				
}




//CLASE ESTADO
class Estado{
	Vector mov = new Vector();
	int profundidad;
	Nodo padre;
	int aux[]={2,3,4,1,9,6,8,7,5};
	
	

        Estado(){		//constructor 1
        	for (int i=0;i<9;i++)
        	{
        		Integer num=new Integer(aux[i]);
        		mov.addElement(num);
        	}
          padre=null;
          profundidad=0;
        }//constructor Estado
        
        Estado(Vector movi,Nodo pa,int pr){   //constructor 2
			  mov=movi;
              padre=pa;
			  profundidad=pr;             
        }//constructor Estado
        
        void describe(){ //Metodo para describir un estado
					System.out.println("Profundidad : " + profundidad);
					System.out.println("Vector mov del Estado: "+mov);
		}	
					
		boolean objetivo(Vector estfin)
		{
			return mov.equals(estfin);
		}
		
		int buscablanco()
		{
		    Integer blanco=new Integer(9);
		    int indice;
		    //si lo encuentra devuelve el indice
		    //si no lo encuentra devuelve -1
		    indice=mov.indexOf(blanco);
		    return indice;
		}//buscablanco
		
}



public class puzzprof{
	
	static boolean estaencerrados(Estado est, Vector ce)
	{
		int i=0, sw=0;
		Estado el_estado=new Estado();
		Vector auxiliar=new Vector();
		Vector auxiliar2=new Vector();
		while((i<ce.size())&&(sw==0))
		{
			el_estado=(Estado)ce.elementAt(i);
			auxiliar=(Vector)est.mov.clone();//estado que viene pasado por param y que es el estado de los que se han expandidos abajo
			auxiliar2=(Vector)el_estado.mov.clone();//estado de cada elemento de cerrados
			if (auxiliar.equals(auxiliar2)) //si son iguales los vectores
			{
				sw=1;
				//System.out.println("HAY UN NODO IGUAL EN CERRADOS");
			}//if
			i++;
		}//while
		 if (sw==0) //no esta en cerrados
		 	return false;
		 else return true; //si que esta en cerrados (sw==1)
	}//estaencerrados	
	
public static void main(String[] args){
		 int iteraciones=0,x;
		 boolean fin=false, res=false;
		 Stack resultado = new Stack();//para el resultado final
     Estado el_estado=new Estado ();
		 Nodo el_nodo=new Nodo(el_estado);
		 Nodo el_nodo2;
		 Estado el_estado2;
		 Vector estfin=new Vector();
		 Vector aux=new Vector();
		 Vector cerrados=new Vector();
		 Vector abiertos=new Vector();
		 int aux2[]={1,2,3,8,9,4,7,6,5};
     //int aux2[]={2,3,4,1,7,6,8,5,9};

	   for (int i=0;i<9;i++)
     {
      	Integer num=new Integer(aux2[i]);
      	estfin.addElement(num);
     }
     
     abiertos.addElement(el_nodo);
		 cerrados.addElement(el_estado);
		 //System.out.println("Vector cerrados: "+cerrados);
		 while(fin==false)
		 {
		      try { 
						el_nodo = (Nodo) abiertos.firstElement();
					}
					catch (NoSuchElementException e){
								System.out.println("Nodo objetivo imposible de alcanzar");	
					}
					el_estado=el_nodo.este;
		 	    cerrados.addElement(el_estado);
		 	    //System.out.println("Vector abiertos al ppio: "+abiertos);
		 	    if (abiertos.size()>0) abiertos.removeElementAt(0);
		 			//el_nodo = new Nodo(el_estado);
		 			//System.out.println("Nodo elegido: "+el_nodo+" y su contenido es: ");
		 			//el_nodo.describe();
			    //p=el_estado.profundidad;
			    //System.out.println("Valor de profundidad de un estado al ppio "+p);
			    
			    //para expandirlo no ha de estar ni en abiertos ni en cerrados ni ser de pr>8
			    if (!el_estado.objetivo(estfin)){
						aux=el_nodo.Expandir(el_estado);
						//System.out.println("Vector aux despues de expandir: "+aux);
						//System.out.println("ANADIENDO EN ABIERTOS");
						x=0;
						while(x<aux.size())
	    			{
							el_estado2=(Estado)aux.elementAt(x);
							if (el_estado2.profundidad==10) //si ha llegado al nivel 3 del arbol se pararia y se 
								//miraria los siguientes nodos que estaban en abiertos, pasando al siguiente nodo siguiente
	    				{
	    					System.out.println("EL_ESTADO2.PROFUNDIDAD: "+el_estado2.profundidad);
	    					if (el_estado.objetivo(estfin)==true) fin=true;
	    				}//if
							res=estaencerrados(el_estado2, cerrados);
							if (res==false) //si el_estado enviado no esta en cerrados->se a�ade a abiertos
	    				{
	    						//System.out.println("Nodo a insertar en abiertos: ");
									//el_estado2.describe();
				    			//a�ade al final de abiertos
				    			el_nodo2=new Nodo(el_estado2);
									//abiertos.addElement(el_nodo2); //a�ade el valor al vector abiertos
									abiertos.insertElementAt(el_nodo2,0);
									//System.out.println("SE ANADE EN ABIERTOS "+el_nodo2);
									//aux.removeElementAt(0);
							}//if.  Si el_estado esta en cerrados no se inserta en abiertos
	    				x++;
	    			}//while
	    			//System.out.println("Vector abiertos despues de a�adir los expandidos: "+abiertos); 
	    			aux.removeAllElements();
						}//if
			  		else
			  		{ 
					    	fin=true;
			    			System.out.println("ESTADO OBJETIVO ENCONTRADO");
			  		}//else			    
		 		iteraciones++;
		 		if (iteraciones==15) fin=true;
	   }//while
	     
	   
	   //falla algo con el nodo igual el_nodo
	   //ordena desde objetivo hasta raiz 
			while(el_nodo!=null){
				resultado.add(el_nodo);
				el_nodo=el_nodo.este.padre;
			}//while
			System.out.println();
			System.out.println("Objetivo alcanzado en "+iteraciones+" iteraciones");
			/*System.out.println("Secuencia de pasos");
			while(!resultado.isEmpty()){
				el_nodo=(Nodo)resultado.pop();//almacena en pila
				el_nodo.describe();
 			}//while*/
	}//main
}//puzzanch