import java.io.*;
import java.util.*;

class Nodo{
				Estado este;
				
				Nodo(Estado pest){		// Constructor del nodo a partir de un estado.
				 este = new Estado(pest.mov,pest.padre,pest.profundidad);
				}

			  //Crea un vector de estados que se van a expandir a partir del actual
			  Vector Expandir(Estado e){
							int pr,i, indice;
							Integer blanco=new Integer(9);
							Vector nuevos = new Vector();	
							Vector auxiliar=new Vector();
							Vector auxiliar2=new Vector();
							Estado aux;
							Integer num;
							auxiliar=(Vector)e.mov.clone(); //creo un clone del vector para que si modifico
							                                //valores en auxiliar no se modifiquen en e.mov							                           
							auxiliar2=(Vector)auxiliar.clone(); //vector auxiliar por si hay cambios en auxiliar.
							indice=e.buscablanco();
						  //System.out.println("Indice encontrado en este estado: "+indice);  
						  //System.out.println("Profundidad en expandir: "+e.profundidad);  
						    //hace movimiento mover arriba
						    if (indice!=-1) //si no ha habido fallo buscando el blanco en este estado
			  				{	
						    	if ((indice>=0)&&(indice<=5)) //si se puede hacer el mvto hacia arriba
						    	{
						     	auxiliar=(Vector)auxiliar2.clone();
						    	num=(Integer)auxiliar.elementAt(indice+3);
			    				auxiliar.removeElementAt(indice);
               	auxiliar.insertElementAt(num,indice);
			          	auxiliar.removeElementAt(indice+3);
			          	auxiliar.insertElementAt(blanco,indice+3);
	               //System.out.println("Vector auxiliar despues de moverarriba: "+auxiliar);
						    	pr=e.profundidad+2;					
						    	aux=new Estado(auxiliar,null,pr-1);
						    	aux.padre = this;
						    	nuevos.addElement(aux);
						    	}
			  				}
						    else System.out.println("ERROR LOCALIZANDO EL BLANCO en mover arriba");
						    
						    
						    //hace movimiento mover abajo
						    if (indice!=-1) //si no ha habido fallo buscando el blanco en este estado
			  				{		
						    	if ((indice>=3)&&(indice<=8)) //si se puede hacer el mvto hacia abajo
						    	{
						    	auxiliar=(Vector)auxiliar2.clone();
						    	num=(Integer)auxiliar.elementAt(indice-3);
			    				auxiliar.removeElementAt(indice);
               	auxiliar.insertElementAt(num,indice);
			          	auxiliar.removeElementAt(indice-3);
			          	auxiliar.insertElementAt(blanco,indice-3);
               	//System.out.println("Vector auxiliar despues de moverabajo: "+auxiliar);
						    	pr=e.profundidad+2;					
						    	aux=new Estado(auxiliar,null,pr-1);
						    	aux.padre = this;
						    	nuevos.addElement(aux);
						    	}
			  				}
						    else System.out.println("ERROR LOCALIZANDO EL BLANCO en mover abajo");
						    
						    
						    //hace movimiento mover derecha
						    if (indice!=-1) //si hay blanco
			  				{
			  					if ((indice!=0)&&(indice!=3)&&(indice!=6)) //si se puede hacer el mvto hacia la derecha
						    	{
						    	auxiliar=(Vector)auxiliar2.clone();
						    	num=(Integer)auxiliar.elementAt(indice-1);
			    				auxiliar.removeElementAt(indice);
               	auxiliar.insertElementAt(num,indice);
			          	auxiliar.removeElementAt(indice-1);
			          	auxiliar.insertElementAt(blanco,indice-1);
               	//System.out.println("Vector auxiliar despues de moverderecha: "+auxiliar);
						    	pr=e.profundidad+2;					
						    	aux=new Estado(auxiliar,null,pr-1);
						    	aux.padre = this;
						    	nuevos.addElement(aux);
						    	}
			  				}
						    else System.out.println("ERROR LOCALIZANDO EL BLANCO en mover derecha");

								//hace movimiento mover izquierda
								if (indice!=-1) //si hay blanco
			  				{
			  					if ((indice!=2)&&(indice!=5)&&(indice!=8)) //si se puede hacer el mvto hacia la derecha
						    	{
						    	auxiliar=(Vector)auxiliar2.clone();
						    	num=(Integer)auxiliar.elementAt(indice+1);
			    				auxiliar.removeElementAt(indice);
               	auxiliar.insertElementAt(num,indice);
			          	auxiliar.removeElementAt(indice+1);
			          	auxiliar.insertElementAt(blanco,indice+1);
               	//System.out.println("Vector auxiliar despues de moverizquierda: "+auxiliar);
						    	pr=e.profundidad+2;					
						    	aux=new Estado(auxiliar,null,pr-1);
						    	aux.padre = this;
						    	nuevos.addElement(aux);
						    	}
			  				}
						    else System.out.println("ERROR LOCALIZANDO EL BLANCO en mover izquierda");


						    
						    return nuevos;
				}//Exapandir
									
			 		
				//Describe un estado , generalmente el actual	
				void describe(){
					System.out.println("Nodo actual:");
					este.describe();
				}				
				
}




//CLASE ESTADO
class Estado{
	Vector mov = new Vector();
	int profundidad;
	Nodo padre;
	int aux[]={2,3,4,1,9,6,8,7,5};
	
	

        Estado(){		//constructor 1
        	for (int i=0;i<9;i++)
        	{
        		Integer num=new Integer(aux[i]);
        		mov.addElement(num);
        	}
          padre=null;
          profundidad=0;
        }//constructor Estado
        
        Estado(Vector movi,Nodo pa,int pr){   //constructor 2
			  mov=movi;
              padre=pa;
			  profundidad=pr;             
        }//constructor Estado
        
        void describe(){ //Metodo para describir un estado
					System.out.println("Profundidad : " + profundidad);
					System.out.println("Vector mov del Estado: "+mov);
		}	
					
		boolean objetivo(Vector estfin)
		{
			return mov.equals(estfin);
		}
		
		int buscablanco()
		{
		    Integer blanco=new Integer(9);
		    int indice;
		    //si lo encuentra devuelve el indice
		    //si no lo encuentra devuelve -1
		    indice=mov.indexOf(blanco);
		    return indice;
		}//buscablanco
		
}



public class puzzanch7{
public static void main(String[] args){
		 int iteraciones=0;
		 boolean fin=false;
		 Stack resultado = new Stack();//para el resultado final
     Estado el_estado=new Estado ();
		 Nodo el_nodo=new Nodo(el_estado);
		 Vector estfin=new Vector();
		 Vector aux=new Vector();
		 Vector abiertos=new Vector();
		 int aux2[]={1,2,3,8,9,4,7,6,5};
     //int aux2[]={2,3,4,1,7,6,8,5,9};

	   for (int i=0;i<9;i++)
     {
      	Integer num=new Integer(aux2[i]);
      	estfin.addElement(num);
     }
     
     //abiertos=el_nodo.ordena(abiertos);//ordeno abiertos por coste
		 abiertos.addElement(el_estado);
		 while(fin==false)
		 {
	       try { 
						el_estado = (Estado) abiertos.firstElement();
					}
					catch (NoSuchElementException e){
								System.out.println("Nodo objetivo imposible de alcanzar");	
					}	
		 	    if (abiertos.size()>0) abiertos.removeElementAt(0);
		 			el_nodo = new Nodo(el_estado);
			    //el_nodo.describe();//describo el nodo actual
			    //p=el_estado.profundidad;
			    //System.out.println("Valor de profundidad de un estado al ppio "+p);
			    
			    //para expandirlo no ha de estar ni en abiertos ni en cerrados ni ser de pr>8
			    if (!el_estado.objetivo(estfin)){
						aux=el_nodo.Expandir(el_estado);
						//System.out.println("Vector aux despues de expandir: "+aux);
						while (aux.size()!=0){ //mientras tenga elementos para expandir
							abiertos.addElement(aux.firstElement()); //a�ade el valor al vector abiertos
							aux.remove(0);
						}//while
							//System.out.println("Resultado de abiertos"+abiertos);
					}//if
			    else
			    { 
			    	fin=true;
			    	System.out.println("ESTADO OBJETIVO ENCONTRADO");
			    }//else			    
			    iteraciones++;
			    if (iteraciones==10000) fin=true;
	   		}//while
	   
	   //igual falta algo para el nodo inicial.
	   
	   
	   //falla algo con el nodo igual el_nodo
	   //ordena desde objetivo hasta raiz 
			while(el_nodo!=null){
				resultado.add(el_nodo);
				el_nodo=el_nodo.este.padre;
			}//while
			System.out.println();
			System.out.println("Objetivo alcanzado en "+iteraciones+" iteraciones");
			System.out.println("Secuencia de pasos");
			while(!resultado.isEmpty()){
				el_nodo=(Nodo)resultado.pop();//almacena en pila
				el_nodo.describe();
 			}//while
	}//main
}//puzzanch