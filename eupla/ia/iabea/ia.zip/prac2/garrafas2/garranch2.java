import java.io.*;
import java.util.*;

/*Solucion al problema de las garrafas Busqueda en anchura, a�adiendo en abiertos por el final*/
//Implementado con 2 soluciones: 2 litros en la garrafa de 3 litros o 2 litros en la garrafa de 4 litros

class Nodo{
	Testado estado;
	Nodo	padre;
	int profundidad;

 Nodo(Testado estado,Nodo padre,int profundidad){//Constructor del nodo a partir de un estado
	this.estado=new Testado(estado.g3,estado.g4);
	this.padre=padre;
	this.profundidad=profundidad;
 }

 Vector Expandir(){
	Vector nuevos=new Vector(); //cjto de nodos expandidos
	Nodo nodo; //cada nodo expandido
	Testado aux;
	//ejecutar todas las funciones y se expanden las que sean posibles
	//System.out.println("Estado.g3 "+estado.g3+"Estado.g4 "+estado.g4+" antes de expandir VACIA3");
	aux=estado.vacia3();
 	if (aux!=null){
 		 nodo=new Nodo(aux,this,profundidad+1);
 		 nuevos.add(nodo);
 	}
 //System.out.println("Estado.g3 "+estado.g3+"Estado.g4 "+estado.g4+" antes de expandir VACIA4");	
 aux=estado.vacia4();
 if (aux!=null)
 {
 	nodo=new Nodo(aux,this,profundidad+1);
  nuevos.add(nodo);	
 }
 //System.out.println("Estado.g3 "+estado.g3+"Estado.g4 "+estado.g4+" antes de expandir LLENA3");
 aux=estado.llena3();
 if (aux!=null)
 {
 	 nodo=new Nodo(aux,this,profundidad+1);
 	 nuevos.add(nodo);
 }
 
 //System.out.println("Estado.g3 "+estado.g3+"Estado.g4 "+estado.g4+" antes de expandir LLENA4");
 aux=estado.llena4();
 if (aux!=null)
 { 
 	nodo=new Nodo(aux,this,profundidad+1);
 	nuevos.add(nodo);
 }
 //System.out.println("Estado.g3 "+estado.g3+"Estado.g4 "+estado.g4+" antes de expandir DERRAMA3_4");
 aux=estado.derrama3sobre4(); 
 nodo=new Nodo(aux,this,profundidad+1);
 nuevos.add(nodo);	
 
 //System.out.println("Estado.g3 "+estado.g3+"Estado.g4 "+estado.g4+" antes de expandir DERRAMA4_3");
 aux=estado.derrama4sobre3(); 
 nodo=new Nodo(aux,this,profundidad+1);
 nuevos.add(nodo);
 
 System.out.println("Vector nuevos despues de expandir: "+nuevos);
 return nuevos;		
 }
 
 void describe(){
 	System.out.println("profundidad: "+profundidad);
 	estado.describe();
 }
 boolean objetivo4()
 {
 	return (this.estado.g4==2);
 }	
 boolean objetivo3(){
 	return (this.estado.g3==2&&this.estado.g4==0);
 }
 void escribe(){
 	estado.describe();
 }//escribe
	

}

class Testado{
	int g3,g4;
 
 public Testado(){this.g3=0;this.g4=0;}
 
 public Testado(int g3,int g4){
  this.g3=g3;this.g4=g4;
 }

public Testado vacia3() {
	if (g3==0) return null;
	else{
		System.out.println("G3: "+g3+"G4: "+g4+"antes de vaciar3");
		return new Testado(0,g4);
	}
	
}
public Testado vacia4(){
	if (g4==0) return null;
	else{
		System.out.println("G3: "+g3+"G4: "+g4+"antes de vaciar4");
		return new Testado(g3,0);
	}
}
public Testado llena3(){
	if (g3==3) return null;
	else{
		System.out.println("G3: "+g3+"G4: "+g4+"antes de llena3");
		return new Testado(3,g4);
	}
}
public Testado llena4(){
	if (g4==4) return null;
	else{
		System.out.println("G3: "+g3+"G4: "+g4+"antes de llena4");
		return new Testado(g3,4);
	}
}

public Testado derrama3sobre4(){
	System.out.println("G3: "+g3+"G4: "+g4+"antes de derrama3_4");
 if(g3<=(4-g4)){
 	return new Testado(0,g3+g4);
 }else{
 	return new Testado(g3-(4-g4),4);
 }
}

public Testado derrama4sobre3(){
	System.out.println("G3: "+g3+"G4: "+g4+"antes de derrama4_3");
 if(g4<=(3-g3)){
	return new Testado(g3+g4,0);
 }else{
	return new Testado(3,g4-(3-g3));
 }
}

public void describe(){
  System.out.println("G3l:"+g3+" G4l:"+g4);
 }
} 

public class garranch2{
	public static void main(String[] args){
 	Vector abiertos=new Vector();
	Stack resultado=new Stack();
	Nodo nodo=null;
	Testado estado=new Testado(0,0);
	boolean fin=false;
	int iteraciones=0;
	Vector aux=new Vector();

    abiertos.add(new Nodo(estado,null,0));//El nodo inicial responde al estado inicial, profundidad 0
						  //y padre nulo
		System.out.println("Vector abiertos: "+abiertos);
    while (!fin){
	    try{
		    	nodo=(Nodo)abiertos.firstElement(); //coger el primer elemento de abiertos
	    }catch(NoSuchElementException e){
	 	    System.out.println("Nodo imposible de alcanzar");
	 	}
	    abiertos.remove(0);
	    System.out.println("Nodo elegido: "+nodo+" y su contenido es: ");
	    nodo.escribe();
	    
	    //controlar si el nodo sacado de abierto es el objetivo
	    if (nodo.objetivo4()) fin=true;//si es el objetivo ->fin
    	//if (nodo.objetivo3()) fin=true;//si es el objetivo ->fin
	    else{
				//Expandir el nodo, tomar lista de nodos expandidos y a�adirlos en abiertos
				aux=nodo.Expandir();
				
				//System.out.println("Vector aux: "+aux);
				    	
	    	//a�ade al final de abiertos
				while (aux.size()!=0){ //mientras tenga elementos para expandir
					abiertos.add(aux.firstElement()); //a�ade el valor al vector abiertos
					aux.remove(0);
				}
				System.out.println("Vector abiertos despues de a�adir los expandidos: "+abiertos);
	    }
	    iteraciones++;
	    if (iteraciones==2)	fin=true;
    }//while
//System.out.println("Abiertos size:"+abiertos.size());
	//ordena desde objetivo hasta raiz 
while(nodo!=null){
	resultado.add(nodo);
	nodo=nodo.padre;
}

System.out.println();
System.out.println("Objetivo alcanzado en "+iteraciones+" iteraciones");
System.out.println("Secuencia de pasos");

 while(!resultado.isEmpty()){
	nodo=(Nodo)resultado.pop();//almacena en pila
	nodo.describe();
 }
}
}