import java.io.*;
import java.util.*;

/*Solucion al problema de las garrafas Busqueda en anchura, a�adiendo a abiertos por detras*/

class Nodo{
	Testado estado;
	Nodo	padre;
	int profundidad;

 Nodo(Testado estado,Nodo padre,int profundidad){//Constructor del nodo a partir de un estado
	this.estado=new Testado(estado.garrafa3,estado.garrafa4);
	this.padre=padre;
	this.profundidad=profundidad;
 }

 Vector Expandir(){
	Vector nuevos=new Vector();
	Testado aux;
 aux=estado.vacia3();if (aux!=null) nuevos.add(new Nodo(aux,this,profundidad+1));
 aux=estado.vacia4();if (aux!=null) nuevos.add(new Nodo(aux,this,profundidad+1));	
 aux=estado.llena3();if (aux!=null) nuevos.add(new Nodo(aux,this,profundidad+1));
 aux=estado.llena4();if (aux!=null) nuevos.add(new Nodo(aux,this,profundidad+1));
 aux=estado.derrama3sobre4(); nuevos.add(new Nodo(aux,this,profundidad+1));	
 aux=estado.derrama4sobre3(); nuevos.add(new Nodo(aux,this,profundidad+1));
 return nuevos;		
 }
 void describe(){
 	System.out.println("profundidad: "+profundidad);
 	estado.describe();
 }
 boolean objetivo(){
 	return (this.estado.garrafa4==2);	
 }	
}
class Testado{
	int garrafa3,garrafa4;
 
 public Testado(){this.garrafa3=0;this.garrafa4=0;}
 
 public Testado(int garrafa3,int garrafa4){
  this.garrafa3=garrafa3;this.garrafa4=garrafa4;
 }

public Testado vacia3() {
	if (garrafa3==0) return null;
	return new Testado(0,this.garrafa4);
}
public Testado vacia4(){
	if (garrafa4==0) return null;
	return new Testado(this.garrafa3,0);
}
public Testado llena3(){
	if (garrafa3==3) return null;
	return new Testado(3,this.garrafa4);
}
public Testado llena4(){
	if (garrafa4==4) return null;
	return new Testado(this.garrafa3,4);
	}

public Testado derrama3sobre4(){
 if(this.garrafa3<=(4-this.garrafa4)){
	return new Testado(0,this.garrafa3+this.garrafa4);
 }else{
	return new Testado(this.garrafa3-(4-this.garrafa4),4);
 }
}

public Testado derrama4sobre3(){
 if(this.garrafa4<=(3-this.garrafa3)){
	return new Testado(this.garrafa3+this.garrafa4,0);
 }else{
	return new Testado(3,this.garrafa4-(3-this.garrafa3));
 }
}

public void describe(){
  System.out.println("               Garrafa de 3l:"+garrafa3+" Garrafa de 4l:"+garrafa4);
 }
} 

public class garrafasArbolAnchura{

	static Vector une(Vector uno,Vector dos){
		while (dos.size()!=0){
			uno.add(dos.firstElement());
			dos.remove(0);
		}
		return uno;
	}
 public static void main(String[] args){
 	Vector abiertos=new Vector();
	Stack resultado=new Stack();
	Nodo nodo=null;
	Testado estado=new Testado(0,0);
	boolean fin=false;
	int iteraciones=0;

    abiertos.add(new Nodo(estado,null,0));//El nodo inicial responde al estado inicial, profundidad 0
						  //y padre nulo
    while (!fin){
	    try{
		    	nodo=(Nodo)abiertos.firstElement();
	    }catch(NoSuchElementException e){
	 	    System.out.println("Nodo imposible de alcanzar");
	 	}
	    abiertos.remove(0);
	    if (nodo.objetivo()) fin=true;
	    else{
		//Expandir el nodo, tomar lista de estados y apuntarlos a abiertos
		//Se a�aden al final de abiertos para busqueda en anchura
			abiertos=une(abiertos,nodo.Expandir());
	    }
	    iteraciones++;
    }//while

//En este momento pasamos a describir el camino correcto
//En primer lugar, ordenamos los nodos de forma inversa a como est�n ordenados
//por razones paternas e introducimos los estados en una pila.

System.out.println("Abiertos size:"+abiertos.size());
	
while(nodo!=null){
	resultado.add(nodo);
	nodo=nodo.padre;
}

System.out.println();
System.out.println("Objetivo alcanzado en "+iteraciones+" iteraciones");
System.out.println("Secuencia de pasos");

 while(!resultado.isEmpty()){
	nodo=(Nodo)resultado.pop();
	nodo.describe();
 }
}
}
