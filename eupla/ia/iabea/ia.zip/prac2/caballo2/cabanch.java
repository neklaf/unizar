//PROBLEMA DEL SALTO DEL CABALLO CON BUSQUEDA EN ANCHURA

import java.io.*;
import java.util.*;
import java.lang.*;

class Nodo{
				Estado este;
				
				
				Nodo(Estado pest){		// Constructor del nodo a partir de un estado.
				 este = new Estado(pest.mov,pest.padre,pest.profundidad);
				}
			
				//mover primer caballo blanco		
				boolean moverblanco(int indice, Vector auxiliar)
				{
					String valor,valor2;
					char aux[]={'9'};
					String vacio=new String(aux,0,1);
					
					//System.out.println("Dentro de moverblanco, valor de indice "+indice+" y auxiliar: "+auxiliar);
					if (indice<4)
					{
						valor=(String)auxiliar.elementAt(indice+5);
						if (valor.equals(vacio))
						{
							System.out.println("MOVER BLANCO1 ");
							valor2=(String)auxiliar.elementAt(indice);
							auxiliar.removeElementAt(indice+5);
							auxiliar.removeElementAt(indice);
							auxiliar.insertElementAt(valor, indice);
							auxiliar.insertElementAt(valor2, indice+5);
							//System.out.println("Vector auxiliar despues de mover: "+auxiliar);
						  return true;	
						}//if			
					}//if	
					return false;				
				}//moverblanco
				
				//mover segundo caballo blanco
				boolean moverblanco2(int indice, Vector auxiliar)
				{
					String valor,valor2;
					char aux[]={'9'};
					String vacio=new String(aux,0,1);
					
					//System.out.println("Dentro de moverblanco2, valor de indice "+indice+" y auxiliar: "+auxiliar);
					if (indice<2)
					{
						valor=(String)auxiliar.elementAt(indice+7);
						if (valor.equals(vacio))
						{
							System.out.println("MOVER BLANCO2 ");
							valor2=(String)auxiliar.elementAt(indice);
							auxiliar.removeElementAt(indice+7);
							auxiliar.removeElementAt(indice);
							auxiliar.insertElementAt(valor, indice);
							auxiliar.insertElementAt(valor2, indice+7);
							//System.out.println("Vector auxiliar despues de mover2: "+auxiliar);
							return true;
						}//if
					}//if					
					return false;
				}//moverblanco2
				
				boolean moverblanco3(int indice, Vector auxiliar)
				{
					String valor,valor2;
					char aux[]={'9'};
					String vacio=new String(aux,0,1);
					
					//System.out.println("Dentro de moverblanco2, valor de indice "+indice+" y auxiliar: "+auxiliar);
					if ((indice==5)||(indice==2))
					{
						valor=(String)auxiliar.elementAt(indice+1);
						if (valor.equals(vacio))
						{
							System.out.println("MOVER BLANCO3 ");
							valor2=(String)auxiliar.elementAt(indice);
							auxiliar.removeElementAt(indice+1);
							auxiliar.removeElementAt(indice);
							auxiliar.insertElementAt(valor, indice);
							auxiliar.insertElementAt(valor2, indice+1);
							//System.out.println("Vector auxiliar despues de mover3: "+auxiliar);
							return true;
						}//if
					}//if
					return false;					
				}//moverblanco3

				boolean movernegro(int indice, Vector auxiliar)
				{
					String valor,valor2;
					char aux[]={'9'};
					String vacio=new String(aux,0,1);
					
					//System.out.println("Dentro de moverblanco, valor de indice "+indice+" y auxiliar: "+auxiliar);
					if (indice>4)
					{
						valor=(String)auxiliar.elementAt(indice-5);
						//System.out.println("En movernegro, valor: "+valor);
						if (valor.equals(vacio))
						{
							System.out.println("MOVER NEGRO1 ");
							valor2=(String)auxiliar.elementAt(indice);
							auxiliar.removeElementAt(indice);
							auxiliar.insertElementAt(valor, indice);
							auxiliar.removeElementAt(indice-5);
							auxiliar.insertElementAt(valor2, indice-5);
							//System.out.println("Vector auxiliar despues de mover: "+auxiliar);
						  return true;	
						}//if			
					}//if	
					return false;				
				}//movernegro				
				
				
				boolean movernegro2(int indice, Vector auxiliar)
				{
					String valor,valor2;
					char aux[]={'9'};
					String vacio=new String(aux,0,1);
					
					//System.out.println("Dentro de moverblanco2, valor de indice "+indice+" y auxiliar: "+auxiliar);
					if (indice>6)
					{
						valor=(String)auxiliar.elementAt(indice-7);
						if (valor.equals(vacio))
						{
							System.out.println("MOVER NEGRO2 ");
							valor2=(String)auxiliar.elementAt(indice);
							auxiliar.removeElementAt(indice);
							auxiliar.insertElementAt(valor, indice);
							auxiliar.removeElementAt(indice-7);
							auxiliar.insertElementAt(valor2, indice-7);
							//System.out.println("Vector auxiliar despues de mover2: "+auxiliar);
							return true;
						}//if
					}//if					
					return false;
				}//movernegro2
				
				boolean movernegro3(int indice, Vector auxiliar)
				{
					String valor,valor2;
					char aux[]={'9'};
					String vacio=new String(aux,0,1);
					
					//System.out.println("Dentro de moverblanco2, valor de indice "+indice+" y auxiliar: "+auxiliar);
					if ((indice==6)||(indice==3))
					{
						valor=(String)auxiliar.elementAt(indice-1);
						if (valor.equals(vacio))
						{
							System.out.println("MOVER NEGRO3 ");
							valor2=(String)auxiliar.elementAt(indice);
							auxiliar.removeElementAt(indice);
							auxiliar.insertElementAt(valor, indice);
							auxiliar.removeElementAt(indice-1);
							auxiliar.insertElementAt(valor2, indice-1);
							//System.out.println("Vector auxiliar despues de mover3: "+auxiliar);
							return true;
						}//if
					}//if
					return false;					
				}//movernegro3


			  //Crea un vector de estados que se van a expandir a partir del actual
			  Vector Expandir(Estado e){
							int pr,i, indice;
							boolean res;
							Integer blanco=new Integer(9);
							Vector nuevos = new Vector();	
							Vector auxiliar=new Vector();
							Vector auxiliar2=new Vector();
							Vector indices=new Vector();//vector con los indices de donde estan los caballos 
							Estado aux;
							Integer num;
							char cabblanco[]={'b'};
							char cabnegro[]={'n'};
							auxiliar=(Vector)e.mov.clone(); //creo un clone del vector para que si modifico
							                                //valores en auxiliar no se modifiquen en e.mov							                           
							auxiliar2=(Vector)auxiliar.clone(); //vector auxiliar por si hay cambios en auxiliar.
							
							//mover caballo blanco
							//busca las posiciones del caballo blanco para luego hacer sus movimientos posibles
							String cb=new String (cabblanco,0,1);
							indice=-1;
							indice=auxiliar.indexOf(cb,indice+1);
			  			num=new Integer(indice);
			  			indices.addElement(num);
			  			indice=auxiliar.indexOf(cb,indice+1);
			  			num=new Integer(indice);
			  			indices.addElement(num);
							indice=auxiliar.indexOf(cb,indice+1);
			  			num=new Integer(indice);
			  			indices.addElement(num);
							
							//System.out.println("Vector de indices: "+indices);

							//luego recorrer todo el vector de indices y hacer todo los siguiente con cada indice
							for (int x=0;x<indices.size();x++)
			  			{
								Integer indice2=(Integer)indices.elementAt(x);
								indice=indice2.intValue();
								//System.out.println("Primer encuentro de cb: "+indice);
							
								res=moverblanco(indice, auxiliar);							
								if (res) //si ha habido cambios->crear un nuevo estado
			  				{	
			  					//System.out.println("Cambios en auxiliar despues de mover blanco: "+auxiliar);
									pr=e.profundidad+2;					
				    			aux=new Estado(auxiliar,null,pr-1);
				    			aux.padre = this;
				    			nuevos.addElement(aux);
			  				}
							
								auxiliar=(Vector)auxiliar2.clone(); 
								res=moverblanco2(indice, auxiliar);								
								if (res)
			  				{
			  					//System.out.println("Cambios en auxiliar despues de mover blanco2: "+auxiliar);
									pr=e.profundidad+2;					
						  		aux=new Estado(auxiliar,null,pr-1);
						  		aux.padre = this;
						  		nuevos.addElement(aux);
			  				}
							
								auxiliar=(Vector)auxiliar2.clone(); 
								res=moverblanco3(indice, auxiliar);
								if (res)
			  				{
			  					//System.out.println("Cambios en auxiliar despues de mover blanco3: "+auxiliar);
									pr=e.profundidad+2;					
				    			aux=new Estado(auxiliar,null,pr-1);
				    			aux.padre = this;
				    			nuevos.addElement(aux);
			  				}
			  			}//for
							
							
							//mover caballo negro
							//busca las posiciones del caballo negro para luego hacer sus movimientos posibles
							auxiliar=(Vector)auxiliar2.clone(); 
							indices.removeAllElements();
							String cn=new String (cabnegro,0,1);
							indice=-1;
							indice=auxiliar.indexOf(cn,indice+1);
			  			num=new Integer(indice);
			  			indices.addElement(num);
			  			indice=auxiliar.indexOf(cn,indice+1);
			  			num=new Integer(indice);
			  			indices.addElement(num);
							indice=auxiliar.indexOf(cn,indice+1);
			  			num=new Integer(indice);
			  			indices.addElement(num);
							
							//System.out.println("VECTOR DE INDICES: "+indices);

							//luego recorrer todo el vector de indices y hacer todo los siguiente con cada indice
							for (int x=0;x<indices.size();x++)
			  			{
								Integer indice2=(Integer)indices.elementAt(x);
								indice=indice2.intValue();
								//System.out.println("Primer encuentro de cn: "+indice);
							
								res=movernegro(indice, auxiliar);							
								if (res) //si ha habido cambios->crear un nuevo estado
			  				{	
			  					//System.out.println("Cambios en auxiliar despues de mover negro: "+auxiliar);
									pr=e.profundidad+2;					
				    			aux=new Estado(auxiliar,null,pr-1);
				    			aux.padre = this;
				    			nuevos.addElement(aux);
			  				}
							
								auxiliar=(Vector)auxiliar2.clone(); 
								res=movernegro2(indice, auxiliar);								
								if (res)
			  				{
			  					//System.out.println("Cambios en auxiliar despues de mover negro2: "+auxiliar);
									pr=e.profundidad+2;					
						  		aux=new Estado(auxiliar,null,pr-1);
						  		aux.padre = this;
						  		nuevos.addElement(aux);
			  				}
							
								auxiliar=(Vector)auxiliar2.clone(); 
								res=movernegro3(indice, auxiliar);
								if (res)
			  				{
			  					//System.out.println("Cambios en auxiliar despues de mover negro3: "+auxiliar);
									pr=e.profundidad+2;					
				    			aux=new Estado(auxiliar,null,pr-1);
				    			aux.padre = this;
				    			nuevos.addElement(aux);
			  				}
			  			}//for
							return nuevos;
				}//Exapandir
									
			 		
				//Describe un estado , generalmente el actual	
				void describe(){
					System.out.println("Nodo actual:");
					este.describe();
				}				
				
}




//CLASE ESTADO
class Estado{
	//Estado de cada nodo
	Vector mov = new Vector(); //vector con los movimientos de cada nodo
	int profundidad; //profundidad en el arbol
	Nodo padre; //puntero al nodo padre que lo expande
	char aux[]={'b','b','b','9','9','9','n','n','n'};		//para inicializar el vector de movimientos con los valores iniciales
	
	

        Estado(){		//constructor que da los valores iniciales al vector de movimientos
        	for (int i=0;i<9;i++)
        	{	
						String valor3=new String(aux, i, 1);
						mov.add(valor3);
					}
          padre=null;
          profundidad=0;
        }//constructor Estado
        
        Estado(Vector movi,Nodo pa,int pr){   //constructor que asigna los valores a cada nodos
					  mov=movi;
           padre=pa;
			  		profundidad=pr;             
        }//constructor Estado
        
        void describe(){ //Metodo para describir un estado
					System.out.println("Profundidad : " + profundidad);
					System.out.println("Vector mov del Estado: "+mov);
		}	
					
		boolean objetivo(Vector estfin)
		{
			return mov.equals(estfin); //compara vector de estado final con el vector del estado para ver si es 
				//el objetivo
		}
}



public class cabanch{
public static void main(String[] args){
		 int iteraciones=0;
		 boolean fin=false;
		 Stack resultado = new Stack();//para el resultado final
     Estado el_estado=new Estado ();
		 Nodo el_nodo=new Nodo(el_estado);
		 Vector estfin=new Vector();
		 Vector aux=new Vector();
		 Vector abiertos=new Vector();//vector abiertos
		 char aux2[]={'n','n','n','9','9','9','b','b','b'};	//estado final 
     
     for (int i=0;i<9;i++)
     {
      	String valor=new String(aux2,i,1);
      	estfin.addElement(valor); 
     }
     //System.out.println("Estado final: "+estfin);
     
     
     //abiertos=el_nodo.ordena(abiertos);//ordeno abiertos por coste
		 abiertos.addElement(el_estado);
		 while(fin==false) //mientras no se consiga el objetivo
		 {
		 			try { 
						el_estado = (Estado) abiertos.firstElement(); //coge cada elemento de abiertos por el principio
					}
					catch (NoSuchElementException e){
								System.out.println("Nodo objetivo imposible de alcanzar");	
					}	
		 	    if (abiertos.size()>0) abiertos.removeElementAt(0);
		 			el_nodo = new Nodo(el_estado);
		 			System.out.println();
			    //el_nodo.describe();//describo el nodo actual
			    		    
			      if (!el_estado.objetivo(estfin)){ //si no es el_estado objetivo
						aux=el_nodo.Expandir(el_estado); //expandir el_estado
						//System.out.println("Vector aux despues de expandir: "+aux);
						//Insertar en abiertos los nodos expandidos
						while (aux.size()!=0){ //mientras tenga elementos para expandir
							abiertos.addElement(aux.firstElement()); //a�ade el valor al vector abiertos
							aux.remove(0);
						}//while
							//System.out.println("Resultado de abiertos"+abiertos);
					}//if
			    else
			    { 
			    	fin=true;
			    	System.out.println("ESTADO OBJETIVO ENCONTRADO");
			    }//else			    
			    iteraciones++;
			    if (iteraciones==500) fin=true;
	   		}//while
	   
	   //igual falta algo para el nodo inicial.
	   
	   //Escribe solucion
	   //ordena desde objetivo hasta raiz 
			while(el_nodo!=null){
				resultado.add(el_nodo);
				el_nodo=el_nodo.este.padre;
			}//while
			System.out.println();
			System.out.println("Objetivo alcanzado en "+iteraciones+" iteraciones");
			System.out.println("Secuencia de pasos");
			while(!resultado.isEmpty()){
				el_nodo=(Nodo)resultado.pop();//almacena en pila
				el_nodo.describe(); 
 			}//while
	}//main
}//puzzanch