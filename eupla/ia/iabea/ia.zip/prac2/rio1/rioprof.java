//PROBLEMA DEL RIO CON BUSQUEDA EN PROFUNDIDAD Y CON VECTOR DE CERRADOS
import java.io.*;
import java.util.*;

class Nodo{
				Estado este;
				
				Nodo(Estado pest){		// Constructor del nodo a partir de un estado.
				 este = new Estado(pest.orillaA,pest.orillaB,pest.padre,pest.profundidad);
				}

			  //Crea un vector de estados que se van a expandir a partir del actual
			  Vector Expandir(Estado e){
							int pr,i, indice;
							Vector nuevos = new Vector();	
							Vector auxiliarA=new Vector();
							Vector auxiliarB=new Vector();
							Vector auxiliar2A=new Vector();
							Vector auxiliar2B=new Vector();
							Estado aux;
							Integer num;
							boolean h=false, o=false, l=false, x=false;
							
							auxiliarA=(Vector)e.orillaA.clone(); 
							auxiliarB=(Vector)e.orillaB.clone(); 					
							auxiliar2A=(Vector)auxiliarA.clone(); 
							auxiliar2B=(Vector)auxiliarB.clone(); 
							
							
							//PRIMERO COMPROBAR EN QUE ORILLA ESTA CADA ELEMENTO POR SI SE CUMPLEN LAS CONDICIONES PARA EL MOVIMIENTO
							for (i=0;i<auxiliarA.size();i++) 
							{
								if (auxiliarA.elementAt(i).equals("h")) h=true;
								if (auxiliarA.elementAt(i).equals("o")) o=true;
								if (auxiliarA.elementAt(i).equals("x")) x=true;
								if (auxiliarA.elementAt(i).equals("l")) l=true;
							}
							for (i=0;i<auxiliarB.size();i++)
							{
								if (auxiliarB.elementAt(i).equals("h")) h=false;
								if (auxiliarB.elementAt(i).equals("o")) o=false;
								if (auxiliarB.elementAt(i).equals("x")) x=false;
								if (auxiliarB.elementAt(i).equals("l")) l=false;
							} 	
							//System.out.println("Profundidad en expandir: "+e.profundidad);  
							//System.out.println("Valores booleanos: ");
							//System.out.println("H: "+h+" O: "+o+" L: "+l+" X: "+x);
							
							//hace pasar_lobo
							//Debe cumplir este movimiento unas cuantas condiciones para poder pasar
							//El lobo y el hombre deben estar en la misma orilla
							if (h==l)
							{
								// La oveja y la lechuga no pueden estar en la misma orilla
								if(o!=x)
								{
									// Ya puede pasar...
									if(h==true)
									{
											//System.out.println("PASAR LOBO");
											String valor = new String("l");
											auxiliarB.addElement(valor);
											auxiliarA.remove(valor);
											valor = new String("h");
											auxiliarB.addElement(valor);
											auxiliarA.remove(valor);
									}//if
									else
								  {
								  		//System.out.println("PASAR LOBO");
											String valor = new String("l");
											auxiliarA.addElement(valor);
											auxiliarB.remove(valor);
											valor = new String("h");
											auxiliarA.addElement(valor);
											auxiliarB.remove(valor);							
									}//else
									pr=e.profundidad+2;
									aux=new Estado(auxiliarA, auxiliarB, null, pr-1);
									aux.padre=this;
									nuevos.addElement(aux);	
								}//if	
							}//if
						  //System.out.println("H: "+h+" O: "+o+" L: "+l+" X: "+x+" despues de pasar_lobo");
						  //System.out.println("AuxiliarA: "+auxiliarA);
						  //System.out.println("AuxiliarB: "+auxiliarB+" despues de pasar_lobo");
						  
						  
						  //hace pasar_oveja
						  auxiliarA=(Vector)auxiliar2A.clone(); 
							auxiliarB=(Vector)auxiliar2B.clone();
						  //Condiciones que se han de cumplir para que pueda pasar la oveja
							//La oveja y el hombre deben estar en la misma orilla.
							if (h==o)
							{
								// Ahora la podemos pasar...
								if(h==true)
								{
									//System.out.println("PASAR OVEJA");
									String valor = new String("o");
									auxiliarB.addElement(valor);
									auxiliarA.remove(valor);
									valor = new String("h");
									auxiliarB.addElement(valor);
									auxiliarA.remove(valor);
								}//if
								else
								{
									//System.out.println("PASAR OVEJA");
									String valor = new String("o");
									auxiliarA.addElement(valor);
									auxiliarB.remove(valor);
									valor = new String("h");
									auxiliarA.addElement(valor);
									auxiliarB.remove(valor);
								}//else
								pr=e.profundidad+2;
								aux=new Estado(auxiliarA, auxiliarB, null, pr-1);
								aux.padre=this;
								nuevos.addElement(aux);
							}//if
							//System.out.println("H: "+h+" O: "+o+" L: "+l+" X: "+x+" despues de pasar_oveja");
							//System.out.println("AuxiliarA: "+auxiliarA);
						  //System.out.println("AuxiliarB: "+auxiliarB+" despues de pasar_oveja");

						  //hace pasar_lechuga
						  auxiliarA=(Vector)auxiliar2A.clone(); 
							auxiliarB=(Vector)auxiliar2B.clone();
							// Para poder pasar a la lechuga, se tendr�n que cumplir algunas condiciones.
							//La leghuga y el hombre deben estar en la misma orilla.
							if (h==x)
							{
								//El lobo y a la oveja no pueden estar en la misma orilla...
								if(l!=o)
								{
									// Ahora la podemos pasar...
									if(h==true)
									{
											//System.out.println("PASAR LECHUGA");
											String valor = new String("x");
											auxiliarB.add(valor);
											auxiliarA.remove(valor);
											valor = new String("h");
											auxiliarB.add(valor);
											auxiliarA.remove(valor);
									}//if
									else
									{
										//System.out.println("PASAR LECHUGA");
										String valor = new String("x");
										auxiliarA.add(valor);
										auxiliarB.remove(valor);
										valor = new String("h");
										auxiliarA.add(valor);
										auxiliarB.remove(valor);
									}//else
									pr=e.profundidad+2;
									aux=new Estado(auxiliarA, auxiliarB, null, pr-1);
									aux.padre=this;
									nuevos.addElement(aux);	
								}//if
							}//if
							//System.out.println("H: "+h+" O: "+o+" L: "+l+" X: "+x+" despues de pasar_lechuga");
							//System.out.println("AuxiliarA: "+auxiliarA);
						  //System.out.println("AuxiliarB: "+auxiliarB+" despues de pasar_lechuga");

						  //hace pasar_de_vacio
						  auxiliarA=(Vector)auxiliar2A.clone(); 
							auxiliarB=(Vector)auxiliar2B.clone();
							// Para poder pasar de vacio, se tendr�n que cumplir algunas condiciones.
							//	1.- Que el lobo y la oveja no est�n en la misma orilla.
							if (l!=o){
								// 2.- Que no dejemos la lechuga y a la oveja juntos...
								if(x!=o){
									// Ahora la podemos pasar...
									if(h==true){
											//System.out.println("PASAR VACIO");
											String valor = new String("h");
											auxiliarB.add(valor);
											auxiliarA.remove(valor);
									}//if
									else {
											//System.out.println("PASAR VACIO");
											String valor = new String("h");
											auxiliarA.add(valor);
											auxiliarB.remove(valor);
									}//else	
									pr=e.profundidad+2;
									aux=new Estado(auxiliarA, auxiliarB, null, pr-1);
									aux.padre=this;
									nuevos.addElement(aux);	
								}//if
							}//if
							//System.out.println("H: "+h+" O: "+o+" L: "+l+" X: "+x+" despues de pasar_vacio");
							//System.out.println("AuxiliarA: "+auxiliarA);
						  //System.out.println("AuxiliarB: "+auxiliarB+" despues de pasar_vacio");
						  return nuevos;
				}//Exapandir
									
			 		
				//Describe un estado , generalmente el actual	
				void describe(){
					System.out.println("Nodo actual:");
					este.describe();
				}				
				
}

//CLASE ESTADO
class Estado{
	boolean h,l,o,x;		//variables para la comprobacion de donde se encuentra cada elemento.
													//si false--> esta en orillaB
													//si true--> esta en orillaA
			int i;
			Vector orillaA = new Vector();
			Vector orillaB = new Vector();
			Nodo padre;
			int profundidad;
			char aux[]={'h','l','o','x'};
		  char aux2[]={};
			
			Estado(){
					for (i=0;i<4;i++){
						String valor=new String(aux, i, 1);
						orillaB.addElement(valor);
					}
			}

			Estado(Vector orillaA, Vector orillaB, Nodo pa, int pr){	// Constructor 2 
				this.orillaA=orillaA;
				this.orillaB=orillaB;
				padre=pa;
				profundidad=pr;
			}
      
     void describe(){ //Metodo para describir un estado
			System.out.println("Profundidad : " + profundidad);
			System.out.println("Orilla A: "+orillaA);
			System.out.println("Orilla B: "+orillaB);
		}	
					
		boolean objetivo()
		{
				for (int i=0;i<orillaA.size();i++) 
				{
					if (orillaA.elementAt(i).equals("h")) h=true;
					if (orillaA.elementAt(i).equals("o")) o=true;
					if (orillaA.elementAt(i).equals("x")) x=true;
					if (orillaA.elementAt(i).equals("l")) l=true;
				}//for
				if ((h==true)&&(o==true)&&(x==true)&&(l==true)) return true;	
				else return false;
					
		}//objetivo
}



public class rioprof{
	
	static void insertaenabiertos(Vector ab, Vector ce, Estado el_estado2)
	{
		Nodo el_nodo2;
		boolean res;
		if (el_estado2.profundidad!=10) 
		{
			//System.out.println("No es de nivel 10");
			//mira si el_estado2 esta en cerrados para no insertarlo en abiertos
			res=estaencerrados(el_estado2, ce);
			if (res==false) //si el_estado enviado no esta en cerrados->se a�ade a abiertos
	  	{
	  		//System.out.println("Se inserta: ");
	  		//el_estado2.describe();
	  		//a�ade al final de abiertos
				el_nodo2=new Nodo(el_estado2);
				ab.insertElementAt(el_nodo2,0);
			}//if.  Si el_estado esta en cerrados no se inserta en abiertos
		}//if
		else
		{
			//System.out.println("No se inserta en abiertos, abiertos: "+ab);
		}//else
	}//insertaenabiertos
	
	static boolean estaencerrados(Estado est, Vector ce)
	{
		int i=0, sw=0;
		Estado el_estado=new Estado();
		Vector auxiliarA=new Vector();
		Vector auxiliarB=new Vector();
		Vector auxiliar2A=new Vector();
		Vector auxiliar2B=new Vector();
		while((i<ce.size())&&(sw==0))
		{
			el_estado=(Estado)ce.elementAt(i);
					
			auxiliarA=(Vector)est.orillaA.clone(); 
			auxiliarB=(Vector)est.orillaB.clone(); 					
			auxiliar2A=(Vector)el_estado.orillaA.clone(); 
			auxiliar2B=(Vector)el_estado.orillaB.clone(); 

			if (auxiliarA.equals(auxiliar2A)&&(auxiliarB.equals(auxiliar2B))) //si son iguales los vectores
			{
				sw=1;
				//System.out.println("HAY UN NODO IGUAL EN CERRADOS");
			}//if
			i++;
		}//while
		 if (sw==0) //no esta en cerrados
		 	return false;
		 else return true; //si que esta en cerrados (sw==1)
	}//estaencerrados	
	
public static void main(String[] args){
		 int iteraciones=0,x;
		 boolean fin=false, res=false;
		 Stack resultado = new Stack();//para el resultado final
     Estado el_estado=new Estado ();
		 Nodo el_nodo=new Nodo(el_estado);
		 Nodo el_nodo2=null;
		 Estado el_estado2=null;
		 Vector estfin=new Vector();
		 Vector aux=new Vector();
		 Vector cerrados=new Vector();
		 Vector abiertos=new Vector();
     
     abiertos.addElement(el_nodo);
		 cerrados.addElement(el_estado);
		 //System.out.println("Vector cerrados: "+cerrados);
		 while(fin==false)
		 {
		      try { 
						el_nodo = (Nodo) abiertos.firstElement();
					}
					catch (NoSuchElementException e){
								System.out.println("Nodo objetivo imposible de alcanzar");	
					}
					el_estado=el_nodo.este;
		 	    cerrados.addElement(el_estado);
		 	    //System.out.println("Vector abiertos al ppio: "+abiertos);
		 	    if (abiertos.size()>0) abiertos.removeElementAt(0);
		 			//el_nodo = new Nodo(el_estado);
		 			//System.out.println("NODO ELEGIDO: ");
		 			//el_nodo.describe();
			    
			    //para expandirlo no ha de estar ni en abiertos ni en cerrados ni ser de pr>8
			    if (!el_estado.objetivo()){
						aux=el_nodo.Expandir(el_estado);
						//System.out.println("Vector aux despues de expandir: "+aux);
						//System.out.println("ANADIENDO EN ABIERTOS");
						x=0;
						while(x<aux.size()&&(fin==false))
	    			{
							el_estado2=(Estado)aux.elementAt(x);
							if (!el_estado2.objetivo()) //por si acaso luego en el nivel que se mira en insertaenabiertos es el suyo y es
								//tambien el nodo objetivo.
	    				{
								insertaenabiertos(abiertos, cerrados, el_estado2);
							}
	    				else
	    				{
	    					 fin=true;
	    					 el_nodo2=new Nodo(el_estado2);
	    					 System.out.println("ESTADO OBJETIVO ENCONTRADO");
	    					 //System.out.println("el_ESTADO2 esta: ");
	    					 //el_estado2.describe();
	    				}//else
	    				x++;
	    			}//while
	    			//System.out.println("Vector abiertos despues de a�adir los expandidos: "+abiertos); 
	    			aux.removeAllElements();
						}//if
			  		else
			  		{ 
					    	fin=true;
			    			System.out.println("ESTADO OBJETIVO ENCONTRADO");
			  		}//else			    
		 		iteraciones++;
		 		if (iteraciones==50) fin=true;
	   }//while
	     
	   
	   //falla algo con el nodo igual el_nodo
	   //ordena desde objetivo hasta raiz 
			while(el_nodo!=null){
				resultado.addElement(el_nodo);
				el_nodo=el_nodo.este.padre;
			}//while
			System.out.println();
			System.out.println("Objetivo alcanzado en "+iteraciones+" iteraciones");
			System.out.println("Secuencia de pasos");
			while(!resultado.isEmpty()){
				el_nodo=(Nodo)resultado.pop();//almacena en pila
				el_nodo.describe();
 			}//while
 			el_nodo2=new Nodo(el_estado2);
			el_nodo2.describe();
	}//main
}//rioprof