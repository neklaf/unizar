class nodo{
	Object dat;
	int typ;
	//nodo sig;

	/*Constructor*/
	nodo(Object o, int i){
		dat=o;
		typ=i;
	}
}

class genInt{
	//Tipos en la pila!!
	static final int INT=0;
	static final int REAL=1;
	static final int STR=2;
	static final int BOOL=3;

	//instrucciones
	static final int ADD=0;
	static final int SUB=1;
	static final int MUL=2;
	static final int DIVI=3;
	static final int EQU=4;
	static final int LSS=5;
	static final int GTR=6;
	static final int LOAD=7;
	static final int LIT=8;
	static final int STO=9;
	static final int CALL=10;
	static final int RET=11;
	static final int RES=12;
	static final int JMP=13;
	static final int FJMP=14;
	static final int HALTc=15;
	static final int NEG=16;
	static final int READ=17;
	static final int WRITE=18;
	static final int SIG=19;



//datos para la generacion de codigo
static int code[]=new int[15000];
static int pc;

//datos para la interpretacion
static nodo stack[]=new nodo[100];
static int progStar;
static int base;
static int top;

/*Datos para almacenar el valor de la pila!!!*/
static int entero;
static boolean booleano;
static float re;
static String cadena;
static nodo N;


static void leeDat(int a){
	switch(a){
		case INT:{entero=((Integer)stack[top].dat).intValue(); break;}
		
		case REAL:{re=((Float)stack[top].dat).floatValue();break;}
		
		case STR:{cadena=((String)stack[top].dat).toString();break;}
		
		case BOOL:{booleano=((Boolean)stack[top].dat).booleanValue();break;}
		default: {System.out.println("No conozco el tipo!!");break;}
	}
}

/******************************STACK***************************************/

/*Cuando nosotros queramos apilar algo, es decir, introducir 
en la posicion top de la pila un valor el dicho valor sera un Object*/

static void Push(nodo n){
	stack[top++]=n;
}

static int Pop(){
	leeDat(stack[--top].typ);
	/*Ahora stack[top] esta apuntado al objeto*/
	return stack[top].typ;
}

/****************************************************************************/

/******************************CODE*****************************************/

static void Emit(int op){
	code[pc++]=op;
}

static void Emit2(int op,int val){
	Emit(op);
	code[pc]=(val/256);
	code[pc+1]=(val % 256);
	pc=pc+2;
}

static void Emit3(int op,int level,int val){
	Emit(op);
	code[pc]=level;
	code[pc+1]=(val/256);
	code[pc+2]=(val%256);
	pc=pc+3;
}

static void Fixup(int adr){
	code[adr]=(pc/256);
	code[adr+1]=(pc%256);
}

static int Next(){
	return code[pc++];
}

static int Next2(){
	int x,y;
	x = code[pc];
	y = code[pc+1];
	pc=pc+2;
	return (x*256+y);
}

/*No estoy muy convencido de q funcione bien este metodo*/
static int Up(int level){
	Object b;
	b=new Integer(base);
	while ( ((Integer)b).intValue() > 0) {
		b=stack[((Integer)b).intValue()].dat;
	}

	return ((Integer)b).intValue();
}

static void Init(){
	pc=1;
	for(int i=0;i<15000;i++){
		code[i]=191;
	}
}

static void leeCod(){
	int lev,val,a;
	String inst;
	pc=1;
	
	for(;;){
		switch(Next()){
			case SIG:{System.out.println("Se�al!!!");break;}
			case ADD:{System.out.println("ADD");break;}
			case SUB:{System.out.println("SUB");break;}
			case MUL:{System.out.println("MUL");break;}
			case DIVI:{System.out.println("DIVI");break;}
			case EQU:{System.out.println("EQU");break;}
			case LSS:{System.out.println("LSS");break;}
			case GTR:{System.out.println("GTR");break;}
			case LOAD:{
				lev=Next();a=Next2();
				System.out.println("LOAD "+lev+","+a);
				break;}
			case LIT:{
				a=Next2();
				System.out.println("LIT "+a);
				break;}
			case STO:{
				lev=Next();a=Next2();
				System.out.println("STO "+lev+","+a);
				break;}
			case CALL:{
				lev=Next();a=Next2();
				System.out.println("CALL "+lev+","+a);
				break;}
			case RET:{System.out.println("RET");break;}
			case RES:{
				a=Next2();
				System.out.println("RES "+a);
				break;}
			case JMP:{
				a=Next2();
				System.out.println("JMP "+a);
				break;}
			case FJMP:{
				a=Next2();
				System.out.println("FJMP "+a);
				break;}
			case HALTc:{System.out.println("HALTc");break;}
			case NEG:{System.out.println("NEG");break;}
			case READ:{
				lev=Next();a=Next2();
				System.out.println("READ "+lev+","+a);
				break;}
			case WRITE:{System.out.println("WRITE");break;}
			case 191: System.exit(0);
			default: System.exit(0);
		}
	}
}

/****************************************************************************/

/*****************************INTERPRET***************************************/

/*static void Interpret(){
	for(;;){
		switch(Next()){
			case ADD:
			case SUB:
			case MUL:
			case DIVI:
			case EQU:
			case LSS:
			case GTR:
			case LOAD:
			case LIT:
			case STO:
			case CALL:
			case RET:
			case RES:
			case JMP:
			case FJMP:
			case HALTc:
			case NEG:
			case READ:
			case WRITE:
			default:
}*/
/****************************************************************************/


}

