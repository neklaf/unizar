import java.io.*;

public class iEst2 {
	StreamTokenizer t;

	public static void main(String args[]){
		BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
		StreamTokenizer t =new StreamTokenizer(b);
		System.out.println("Escribe un entero y pulse <INTRO>: ");
		try{
			t.nextToken();
		}catch(IOException e){ 
			System.out.println("ERROR");
		}
		if(t.ttype == t.TT_NUMBER) System.out.println("Valor: "+(int)t.nval); 
	}
}
