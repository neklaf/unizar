import java.util.*;

class Parser {
	private static final int maxT = 43;
	private static final int maxP = 43;

	private static final boolean T = true;
	private static final boolean x = false;
	private static final int minErrDist = 2;
	private static int errDist = minErrDist;

	static Token token;   // last recognized token
	static Token t;       // lookahead token

	// el cjto de tipos	
	static final int undef = 0;
	static final int integer = 1;
	static final int bool = 2;
	static final int flotante = 3;
	static final int cte = 4;

	// formas para los tipos  (modes)
	static final int vars = 0;
	static final int reg = 1;
	static final int vector = 2;
	static final int proc = 3;      //???

	// instrucciones del codigo intermedio
	static final int ADD=0;
	static final int SUB=1;
	static final int MUL=2;
	static final int DIVI=3;
	static final int EQU=4;
	static final int LSS=5;
	static final int GTR=6;
	static final int LOAD=7;
	static final int LIT=8;
	static final int STO=9;
	static final int CALL=10;
	static final int RET=11;
	static final int RES=12;
	static final int JMP=13;
	static final int FJMP=14;
	static final int HALTc=15;
	static final int NEG=16;
	static final int READ=17;
	static final int WRITE=18;
	

/*----------------------------------------------------------------------------*/



	static void Error(int n) {
		if (errDist >= minErrDist) Scanner.err.ParsErr(n, t.line, t.col);
		errDist = 0;
	}

	static void SemError(int n) {
		if (errDist >= minErrDist) Scanner.err.SemErr(n, token.line, token.col);
		errDist = 0;
	}

	static boolean Successful() {
		return Scanner.err.count == 0;
	}

	static String LexString() {
		return token.str;
	}

	static String LexName() {
		return token.val;
	}

	static String LookAheadString() {
		return t.str;
	}

	static String LookAheadName() {
		return t.val;
	}

	private static void Get() {
		for (;;) {
			token = t;
			t = Scanner.Scan();
			if (t.kind <= maxT) {errDist++; return;}

			t = token;
		}
	}

	private static void Expect(int n) {
		if (t.kind == n) Get(); else Error(n);
	}

	private static boolean StartOf(int s) {
		return set[s][t.kind];
	}

	private static void ExpectWeak(int n, int follow) {
		if (t.kind == n) Get();
		else {
			Error(n);
			while (!StartOf(follow)) Get();
		}
	}

	private static boolean WeakSeparator(int n, int syFol, int repFol) {
		boolean[] s = new boolean[maxT+1];
		if (t.kind == n) {Get(); return true;}
		else if (StartOf(repFol)) return false;
		else {
			for (int i = 0; i <= maxT; i++) {
				s[i] = set[syFol][i] || set[repFol][i] || set[0][i];
			}
			Error(n);
			while (!s[t.kind]) Get();
			return StartOf(syFol);
		}
	}

	private static float Real() {
		float f;
		Expect(1);
		f = (new Float(token.val)).floatValue();
		return f;
	}

	private static boolean Booleano() {
		boolean b;
		Expect(1);
		b = Boolean.valueOf(token.val).booleanValue();
		return b;
	}

	private static void selector() {
		while (t.kind == 7 || t.kind == 41) {
			if (t.kind == 7) {
				Get();
				Expect(1);
			} else {
				Get();
				expresion();
				Expect(42);
			}
		}
	}

	private static String factor1() {
		String type;
		String cad=null; int n; Obj o; type=null;
		if (t.kind == 1) {
			cad = Ident();
			o=tabla.buscaObj(cad);
			if(o==null){ME.SemErr(3,token.line,token.line); }
			else{
			type=new String(o.type.id);
			genInt.Emit3(LOAD,tabla.curLevel-o.level, o.adr);
			}

		} else if (t.kind == 2) {
			n = Entero();
			genInt.Emit2(LIT,n); type=new String("INTEGER");
		} else if (t.kind == 39) {
			Get();
			type=new String("BOOLEAN");
			genInt.Emit2(LIT,1);
		} else if (t.kind == 40) {
			Get();
			type=new String("BOOLEAN");
			genInt.Emit2(LIT,0);
		} else if (t.kind == 34) {
			Get();
			type = factor1();
			if(type.equals("INTEGER")){ME.SemErr(4,token.line,token.col);}
		} else Error(44);
		return type;
	}

	private static String term1() {
		String tp;
		String tc=null; int op=-1;
		tp = factor1();
		while (StartOf(1)) {
			if (t.kind == 35) {
				Get();
				op=MUL;
			} else if (t.kind == 36) {
				Get();
				op=DIVI;
			} else if (t.kind == 37) {
				Get();
				op=-1; //IMPLEMENTAR!!! //SE PUEDE HACER!!
			} else {
				Get();
				op=-1; //NO HARIA FALTA LA ASIGNACION
			}
			tc = factor1();
			if((!tp.equals("INTEGER")) || (!tc.equals("INTEGER"))){ME.SemErr(6,token.line,token.col);}
			genInt.Emit(op);
		}
		return tp;
	}

	private static String ExpresionSimple1() {
		String tp2;
		String tt=null; int op=-1;
		tp2 = term1();
		while (t.kind == 33 || t.kind == 34) {
			if (t.kind == 33) {
				Get();
				op=ADD;
			} else {
				Get();
				op=SUB;
			}
			tt = term1();
			if((!tp2.equals("INTEGER")) || (!tt.equals("INTEGER"))){ME.SemErr(6,token.line,token.col);}
			genInt.Emit(op);
		}
		return tp2;
	}

	private static void ParametrosActuales() {
		Expect(14);
		if (StartOf(2)) {
			expresion();
			while (t.kind == 19) {
				Get();
				expresion();
			}
		}
		Expect(15);
	}

	private static void SentenciaWrite() {
		String cad;
		Expect(26);
		cad = expresion1();
		if(!cad.equals("INTEGER")){ME.SemErr(6,token.line,token.col);}
		genInt.Emit(WRITE);
	}

	private static void SentenciaRead() {
		String cad; Obj o;
		Expect(27);
		cad = Ident();
		o=tabla.buscaObj(cad);
		if(o==null){ME.SemErr(3,token.line,token.line); }
		else{
		if(!o.type.id.equals("INTEGER")){ME.SemErr(6,token.line,token.col);}
		}
		genInt.Emit3(READ,tabla.curLevel-o.level,o.adr);

	}

	private static void SentenciaWhile() {
		int loopstart,fix; String cad;
		Expect(21);
		loopstart=genInt.pc;
		cad = expresion1();
		if(!cad.equals("BOOLEAN")){ME.SemErr(8,token.line,token.col);}
		fix=genInt.pc+1; genInt.Emit2(FJMP,0);

		Expect(22);
		SecuenciaSentencias();
		genInt.Emit2(JMP,loopstart); genInt.Fixup(fix);
		Expect(6);
	}

	private static void SentenciaIf() {
		int fix,fix2=0; String cad;
		Expect(23);
		cad = expresion1();
		if(!cad.equals("BOOLEAN")){ME.SemErr(8,token.line,token.col);}
		fix=genInt.pc+1; genInt.Emit2(FJMP,0);

		Expect(24);
		SecuenciaSentencias();
		if (t.kind == 25) {
			Get();
			fix2=genInt.pc+1; genInt.Emit2(JMP,0);
			genInt.Fixup(fix); fix=fix2;
			SecuenciaSentencias();
		}
		Expect(6);
		genInt.Fixup(fix);
	}

	private static void sentencia1() {
		String cad=null; Obj o; String tp3=null;
		cad = Ident();
		o=tabla.buscaObj(cad);
		if(o==null) {ME.SemErr(3,token.line,token.col); }

		if (t.kind == 14 || t.kind == 20) {
			if (t.kind == 20) {
				Get();
				tp3 = expresion1();
				if(!tp3.equals(o.type.id)){ME.SemErr(5,token.line,token.col);}
				genInt.Emit3(STO,tabla.curLevel-o.level,o.adr);
			} else {
				Get();
				Expect(15);
				if(o.kind!=proc){ME.SemErr(7,token.line,token.col);}
				genInt.Emit3(CALL, tabla.curLevel-o.level, o.adr);
			}
		}
	}

	private static void sentencia() {
		if (StartOf(3)) {
			if (t.kind == 1) {
				sentencia1();
			} else if (t.kind == 23) {
				SentenciaIf();
			} else if (t.kind == 21) {
				SentenciaWhile();
			} else if (t.kind == 27) {
				SentenciaRead();
			} else {
				SentenciaWrite();
			}
		}
	}

	private static void ListaCampos() {
		String cad; Struct t1=null,t2;
		if (t.kind == 1) {
			ListaIdent();
			Expect(12);
			cad = tipo1();
			tabla.pontipo(cad);
			tabla.insAuxR(); //Inserta los campos
			t2=new Struct(cad); t1=tabla.buscaT(t2);
			tabla.aux=null; //Reseteamos la lista de variables!!
		}
	}

	private static void TipoRecord() {
		Expect(16);
		tabla.lt.form=reg; //Marcamos q es un registro
		ListaCampos();
		while (t.kind == 4) {
			Get();
			ListaCampos();
		}
		tabla.lt.size+=tabla.tamReg(); //Ponemos el tamano q ocupara el registro
		Expect(6);
	}

	private static void TipoArray() {
		int i2; String c1=null;
		Expect(17);
		tabla.lt.form=vector;
		i2 = Entero();
		Expect(18);
		c1 = tipo1();
		Struct s3,s4;
		s3=new Struct(c1); s4=tabla.buscaT(s3);
		tabla.lt.size=i2*s4.size;
	}

	private static String expresion1() {
		String tp;
		tp=new String("BOOLEAN"); String tt=null; String tt2=null; int op=-1;
		tt = ExpresionSimple1();
		if (StartOf(4)) {
			switch (t.kind) {
			case 9: {
				Get();
				op=EQU;
				break;
			}
			case 28: {
				Get();
				op=-1; //??
				break;
			}
			case 29: {
				Get();
				op=LSS;
				break;
			}
			case 30: {
				Get();
				op=-1;
				break;
			}
			case 31: {
				Get();
				op=GTR;
				break;
			}
			case 32: {
				Get();
				op=-1;
				break;
			}
			}
			tt2 = ExpresionSimple1();
			if(!tt.equals(tt2)){ME.SemErr(5,token.line,token.col);}
			genInt.Emit(op);
			tp=new String("BOOLEAN");
		}
		return tp;
	}

	private static void expresion() {
		String cad;
		cad = expresion1();
	}

	private static void SeccionPF() {
		String s2=null;
		boolean b=true;
		if (t.kind == 11) {
			Get();
			b=false;
		}
		ListaIdent();
		Expect(12);
		s2 = tipo1();
		tabla.pontipo(s2);tabla.bloquea(b);tabla.insAuxR();
		tabla.aux=null; //Lista aux reseteada!!!
	}

	private static void ParametrosFormales() {
		Expect(14);
		if (t.kind == 1 || t.kind == 11) {
			SeccionPF();
			while (t.kind == 4) {
				Get();
				SeccionPF();
			}
		}
		Expect(15);
	}

	private static void CuerpoProcedimiento() {
		int fix;
		declaraciones();
		if (t.kind == 5) {
			Get();
			fix=genInt.pc+1; genInt.Emit2(JMP,0);
			genInt.Fixup(fix); genInt.Emit2(RES,tabla.DataSpace());
			SecuenciaSentencias();
		}
		Expect(6);
		genInt.Emit(RET);
	}

	private static String CabeceraProcedimiento() {
		String nn1;
		String np=null; Struct s4;
		Expect(13);
		np = Ident();
		nn1=np;
		s4=new Struct(np); tabla.addT(s4);
		tabla.add2(np); tabla.insTablaS();
		tabla.topScope.locals.type=s4; //Asignamos el tipo
		tabla.topScope.locals.adr=genInt.pc;  //Asignamos la @ d comienzo

		tabla.EnterScope();
		if (t.kind == 14) {
			ParametrosFormales();
		}
		return nn1;
	}

	private static void DeclaracionProcedimiento() {
		String name1,name2;
		name1 = CabeceraProcedimiento();
		Expect(4);
		CuerpoProcedimiento();
		name2 = Ident();
		if(!name1.equals(name2)) ME.SemErr(1,token.line,token.col);
		tabla.LeaveScope();
	}

	private static String tipo1() {
		String id;
		Expect(1);
		id=token.val;
		return id;
	}

	private static void ListaIdent() {
		String n1,n2=null;
		n1 = Ident();
		tabla.add(n1); //Inserta en la lista aux
		while (t.kind == 19) {
			Get();
			n2 = Ident();
			tabla.add(n2);
		}
	}

	private static void tipo() {
		if (t.kind == 17) {
			TipoArray();
		} else if (t.kind == 16) {
			TipoRecord();
		} else Error(45);
	}

	private static int Entero() {
		int num;
		Expect(2);
		num=0;
		try{
		num = Integer.parseInt(token.val);
		}catch(Exception e){
		System.out.println("No coge el entero");
		}
		//System.out.println("VALOR: "+num);
		return num;
	}

	private static void SecuenciaSentencias() {
		sentencia();
		while (t.kind == 4) {
			Get();
			sentencia();
		}
	}

	private static void declaraciones() {
		String tv,n1,n2=null,n3; //tabla.EnterScope();
		String nc=null; Obj o1; int en;
		if (t.kind == 8) {
			Get();
			while (t.kind == 1) {
				nc = Ident();
				o1=tabla.NewObj(nc,cte);
				o1.block=true; //Pq a una cte no se le puede modificar el valor
				Expect(9);
				en = Entero();
				Struct st2,st=new Struct("INTEGER");
				st2=tabla.buscaT(st); o1.type=st2;
				o1.val=new Integer(en);
				Expect(4);
				//tabla.topScope.locals.view();
			}
		}
		Struct s;
		if (t.kind == 10) {
			Get();
			while (t.kind == 1) {
				n3 = Ident();
				s=new Struct(n3); //Creo tipo nuevo!!
				tabla.addT(s); //Insertado en la lista de tipos!!
				Expect(9);
				tipo();
				Expect(4);
				//tabla.lt.view();
			}
		}
		if (t.kind == 11) {
			Get();
			while (t.kind == 1) {
				ListaIdent();
				Expect(12);
				tv = tipo1();
				tabla.pontipo(tv);tabla.insTablaS();
				Expect(4);
			}
		}
		while (t.kind == 13) {
			DeclaracionProcedimiento();
			Expect(4);
			//tabla.lt.view();
		}
	}

	private static String Ident() {
		String nombre;
		Expect(1);
		nombre=token.val;
		return nombre;
	}

	private static void oberon() {
		tabla.Init(); String mod1,mod2; genInt.Init();
		Expect(3);
		mod1 = Ident();
		Expect(4);
		genInt.progStar=genInt.pc;
		int fix; String cad=null;
		fix=genInt.pc + 1;
		genInt.Emit2(JMP,0);
		declaraciones();
		if (t.kind == 5) {
			Get();
			genInt.Fixup(fix);
			genInt.Emit2(RES,tabla.DataSpace());
			SecuenciaSentencias();
		}
		Expect(6);
		mod2 = Ident();
		if(!mod1.equals(mod2)) ME.SemErr(2,token.line,token.col);
		genInt.Emit(HALTc);
		//tabla.verScopes();
		ME.resumen();
		Expect(7);
	}



	static void Parse() {
		t = new Token();
		Get();
		oberon();

	}

	private static boolean[][] set = {
	{T,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x},
	{x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,T, T,T,T,x, x,x,x,x, x},
	{x,T,T,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,T,x, x,x,x,T, T,x,x,x, x},
	{x,T,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,T,x,T, x,x,T,T, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x},
	{x,x,x,x, x,x,x,x, x,T,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, T,T,T,T, T,x,x,x, x,x,x,x, x,x,x,x, x}

	};
}
