class ME {
	
 	static int contador;

	ME(){
		contador=0;
	}

	static void SemErr(int n,int line, int col){
		String s;
		contador++;
		switch(n) {
			case -1: {s="Caracter no v�lido";break;}
			case 1: {s="Nombre de procedimiento no esperado";break;}
			case 2: {s="Nombre de m�dulo no esperado";break;}
			default: {s="Error Sem�ntico";break;}
		}
		System.out.println("-- line "+line+" col "+col+": "+s);
	}
	
	static void resumen(){
		switch(contador){
			case 0: {System.out.println("No hay errores semanticos detectados."); break;}
			case 1: {System.out.println("1 Error sem�tico detectado."); break;}
			default: {System.out.println(contador+" Errores sem�nticos detectados."); break;}
		}
	}
}
